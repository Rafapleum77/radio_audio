#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════╗
║   RÁDIO BITADICT — SISTEMA DE AGENTES AUTÓNOMOS V1.0            ║
║   Open Source | Nostr + Lightning | Multi-Agent Swarm           ║
╚══════════════════════════════════════════════════════════════════╝

Agentes incluídos:
  🎙️  NewsAgent     — Busca notícias BTC e gera TTS
  📊  MarketAgent   — Analisa mercado e faz comentários ao vivo
  🎵  MusicAgent    — Compõe letras/prompts Bitcoin com IA
  🤖  ChatAgent     — Responde perguntas com contexto real de BTC
  ⚡  ZapAgent      — Processa doações Lightning + leaderboard
  📡  NostrAgent    — Escuta contribuições via Nostr

Protocolo Open Source:
  - Qualquer IA/developer pode contribuir via Nostr + Zap
  - Músicas submetidas entram na fila de aprovação
  - Mensagens com zap ≥ MIN_ZAP_SATS são lidas ao vivo
  - Código submetido via Nostr entra em review automático

Dependências:
  pip install requests gtts websockets python-dotenv anthropic
"""

import asyncio
import json
import os
import time
import threading
import requests
import logging
from datetime import datetime
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()
logging.basicConfig(level=logging.INFO, format="[%(asctime)s] %(name)s: %(message)s", datefmt="%H:%M:%S")

# ══════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════

ANTHROPIC_KEY      = os.getenv("ANTHROPIC_API_KEY")
LIGHTNING_ADDRESS  = os.getenv("LIGHTNING_ADDRESS", "texugorecords@walletofsatoshi.com")
TG_TOKEN           = os.getenv("TELEGRAM_TOKEN")
TG_CHAT            = os.getenv("TELEGRAM_CHAT_ID")
WS_PORT            = int(os.getenv("WS_PORT", "8765"))
MIN_ZAP_SATS       = int(os.getenv("MIN_ZAP_SATS", "21"))  # mínimo para entrar na rádio

NOSTR_RELAYS = [
    "wss://nos.lol",
    "wss://relay.damus.io",
    "wss://nostr.band",
    "wss://relay.nostr.band",
]

DATA_DIR = Path("radio_dados")
DATA_DIR.mkdir(exist_ok=True)

QUEUE_FILE     = DATA_DIR / "content_queue.json"
LEADERBOARD_FILE = DATA_DIR / "leaderboard.json"
NEWS_CACHE_FILE  = DATA_DIR / "news_cache.json"
MUSIC_QUEUE_FILE = DATA_DIR / "music_queue.json"

# ══════════════════════════════════════════════════════════════════
#  ESTADO GLOBAL
# ══════════════════════════════════════════════════════════════════

estado = {
    "btc_price":    0.0,
    "btc_change":   0.0,
    "btc_high":     0.0,
    "btc_low":      0.0,
    "fear_index":   50,
    "fear_label":   "Neutral",
    "block_height": 0,
    "ws_clients":   set(),
    "leaderboard":  [],
    "content_queue": [],
    "music_queue":  [],
    "on_air":       None,
}

# ══════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════

def salvar_json(path: Path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logging.error(f"Erro ao salvar {path}: {e}")

def carregar_json(path: Path, default):
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return default

def enviar_telegram(msg: str):
    if not TG_TOKEN or not TG_CHAT:
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            data={"chat_id": TG_CHAT, "text": msg, "parse_mode": "Markdown"},
            timeout=10,
        )
    except Exception:
        pass

async def broadcast_ws(data: dict):
    """Envia mensagem a todos os clientes WebSocket conectados."""
    if not estado["ws_clients"]:
        return
    msg = json.dumps(data)
    dead = set()
    for client in estado["ws_clients"]:
        try:
            await client.send(msg)
        except Exception:
            dead.add(client)
    estado["ws_clients"] -= dead

# ══════════════════════════════════════════════════════════════════
#  AGENTE 1 — MARKET AGENT
#  Busca dados BTC ao vivo e faz comentários de mercado
# ══════════════════════════════════════════════════════════════════

class MarketAgent:
    NAME = "MarketAgent"
    log  = logging.getLogger("MarketAgent")

    COMENTARIOS = [
        "Bitcoin segura o suporte! Holders não tremedores.",
        "O mercado testa a paciência dos fracos e recompensa os fortes.",
        "Nível de medo em {fear}. História diz: compra quando há sangue nas ruas.",
        "Bloco #{block} minerado. A rede nunca para. 21 milhões. Imutável.",
        "Volume de {vol}B nas últimas 24h. O dinheiro se move.",
        "High: {high} | Low: {low}. Volatilidade é o preço da liberdade.",
        "Fear & Greed: {fear_lbl}. Contrarian thinking wins.",
        "Stack sats automaticamente. DCA bate timing do mercado 9/10.",
    ]

    async def run(self):
        self.log.info("MarketAgent iniciado")
        while True:
            try:
                await self._fetch_btc()
                await asyncio.sleep(30)
            except Exception as e:
                self.log.error(f"Erro: {e}")
                await asyncio.sleep(60)

    async def _fetch_btc(self):
        try:
            url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true&include_high_24h=true&include_low_24h=true"
            r = requests.get(url, timeout=10)
            d = r.json()["bitcoin"]

            estado["btc_price"]  = d["usd"]
            estado["btc_change"] = d["usd_24h_change"]
            estado["btc_high"]   = d.get("usd_high_24h", d["usd"])
            estado["btc_low"]    = d.get("usd_low_24h", d["usd"])

            await broadcast_ws({
                "type":   "market_update",
                "price":  estado["btc_price"],
                "change": round(estado["btc_change"], 2),
                "high":   estado["btc_high"],
                "low":    estado["btc_low"],
            })

            # Comentário a cada 10 minutos
            if int(time.time()) % 600 < 30:
                await self._comentar()

        except Exception as e:
            self.log.warning(f"Fetch BTC: {e}")

    async def _comentar(self):
        import random
        tmpl = random.choice(self.COMENTARIOS)
        comentario = tmpl.format(
            fear=estado["fear_index"],
            fear_lbl=estado["fear_label"],
            block=estado["block_height"],
            high=f"${estado['btc_high']:,.0f}",
            low=f"${estado['btc_low']:,.0f}",
            vol="--",
        )
        await broadcast_ws({
            "type":    "agent_comment",
            "agent":   self.NAME,
            "message": comentario,
            "price":   estado["btc_price"],
        })
        self.log.info(f"Comentário: {comentario}")

# ══════════════════════════════════════════════════════════════════
#  AGENTE 2 — NEWS AGENT
#  Busca notícias Bitcoin e gera TTS
# ══════════════════════════════════════════════════════════════════

class NewsAgent:
    NAME = "NewsAgent"
    log  = logging.getLogger("NewsAgent")

    async def run(self):
        self.log.info("NewsAgent iniciado")
        while True:
            try:
                await self._fetch_news()
                await asyncio.sleep(1800)  # A cada 30 min
            except Exception as e:
                self.log.error(f"Erro: {e}")
                await asyncio.sleep(300)

    async def _fetch_news(self):
        """Busca notícias Bitcoin via RSS/API pública."""
        try:
            # CryptoPanic API (gratuita)
            url = "https://cryptopanic.com/api/v1/posts/?auth_token=&currencies=BTC&kind=news&public=true"
            r = requests.get(url, timeout=10)
            if not r.ok:
                await self._fallback_news()
                return

            data = r.json()
            results = data.get("results", [])[:5]
            news_items = []

            for item in results:
                title = item.get("title", "")
                if title:
                    news_items.append({
                        "title":    title,
                        "url":      item.get("url", ""),
                        "time":     item.get("published_at", ""),
                        "source":   item.get("source", {}).get("title", ""),
                    })

            if news_items:
                cache = carregar_json(NEWS_CACHE_FILE, [])
                cache = news_items + cache
                cache = cache[:20]
                salvar_json(NEWS_CACHE_FILE, cache)

                await broadcast_ws({
                    "type":  "news_update",
                    "agent": self.NAME,
                    "items": news_items,
                })

                # TTS da primeira notícia
                await self._gerar_tts(news_items[0]["title"])
                self.log.info(f"News: {len(news_items)} itens processados")

        except Exception as e:
            self.log.warning(f"News fetch: {e}")
            await self._fallback_news()

    async def _fallback_news(self):
        """Notícias fallback quando API falha."""
        fallback = [
            f"Bitcoin a ${estado['btc_price']:,.0f}. Mercado {estado['fear_label'].lower()}.",
            "Rede Bitcoin 100% operacional. Miners a proteger a cadeia.",
            "Lightning Network cresce. Mais canais, mais liquidez.",
        ]
        import random
        noticia = random.choice(fallback)
        await broadcast_ws({
            "type":  "news_update",
            "agent": self.NAME,
            "items": [{"title": noticia, "url": "", "time": datetime.now().isoformat(), "source": "BitAdict AI"}],
        })

    async def _gerar_tts(self, texto: str):
        """Gera áudio TTS e envia para a rádio."""
        try:
            from gtts import gTTS
            tts_path = DATA_DIR / "tts_latest.mp3"
            tts = gTTS(text=texto, lang="pt", slow=False)
            tts.save(str(tts_path))
            await broadcast_ws({
                "type":    "tts_ready",
                "agent":   self.NAME,
                "text":    texto,
                "file":    "radio_dados/tts_latest.mp3",
            })
            self.log.info(f"TTS gerado: {texto[:60]}...")
        except ImportError:
            self.log.warning("gtts não instalado. pip install gtts")
        except Exception as e:
            self.log.warning(f"TTS: {e}")

# ══════════════════════════════════════════════════════════════════
#  AGENTE 3 — MUSIC AGENT
#  Gera letras/prompts de música Bitcoin com IA
# ══════════════════════════════════════════════════════════════════

class MusicAgent:
    NAME = "MusicAgent"
    log  = logging.getLogger("MusicAgent")

    PROMPTS_BASE = [
        "Escreve uma estrofe de rap Bitcoin sobre autocustódia e liberdade financeira",
        "Cria uma letra de música sobre o halving Bitcoin e escassez digital",
        "Compõe um refrão sobre Lightning Network e pagamentos instantâneos",
        "Escreve sobre ser um Bitcoiner em Portugal/Brasil enfrentando o sistema fiat",
        "Cria uma letra sobre o Satoshi Nakamoto e a revolução silenciosa do Bitcoin",
    ]

    async def run(self):
        self.log.info("MusicAgent iniciado")
        while True:
            try:
                await self._gerar_letra()
                await asyncio.sleep(3600)  # A cada hora
            except Exception as e:
                self.log.error(f"Erro: {e}")
                await asyncio.sleep(600)

    async def _gerar_letra(self):
        import random
        prompt = random.choice(self.PROMPTS_BASE)
        prompt_completo = f"{prompt}. Contexto atual: BTC=${estado['btc_price']:,.0f}, {estado['fear_label']}. Máximo 8 linhas, estilo @bitadict."

        if ANTHROPIC_KEY:
            letra = await self._gerar_com_claude(prompt_completo)
        else:
            letra = self._gerar_fallback()

        if letra:
            item = {
                "type":      "music_generation",
                "agent":     self.NAME,
                "prompt":    prompt,
                "lyrics":    letra,
                "timestamp": int(time.time()),
                "btc_price": estado["btc_price"],
            }

            queue = carregar_json(MUSIC_QUEUE_FILE, [])
            queue.insert(0, item)
            queue = queue[:10]
            salvar_json(MUSIC_QUEUE_FILE, queue)

            await broadcast_ws(item)
            self.log.info(f"Letra gerada: {letra[:80]}...")

    async def _gerar_com_claude(self, prompt: str) -> str:
        try:
            r = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": ANTHROPIC_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                json={
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 300,
                    "messages": [{"role": "user", "content": prompt}],
                },
                timeout=20,
            )
            d = r.json()
            return d["content"][0]["text"] if r.ok else self._gerar_fallback()
        except Exception as e:
            self.log.warning(f"Claude: {e}")
            return self._gerar_fallback()

    def _gerar_fallback(self) -> str:
        import random
        fallbacks = [
            "21 milhões de razões para ser livre\nA matemática não mente, o banco central mente\nStack sats, ignore o ruído\nBitcoin é a saída",
            "No código confio, não no governo\nChaves privadas, soberania real\nHalving se aproxima, escassez chegando\nO futuro é descentralizado",
            "Lightning rápido como um raio\nSats fluem sem fronteiras\nBancos obsoletos, Bitcoin eterno\nA revolução já começou",
        ]
        return random.choice(fallbacks)

# ══════════════════════════════════════════════════════════════════
#  AGENTE 4 — CHAT AGENT
#  Responde perguntas com contexto real de BTC
# ══════════════════════════════════════════════════════════════════

class ChatAgent:
    NAME = "ChatAgent"
    log  = logging.getLogger("ChatAgent")

    SYSTEM_PROMPT = """És o BITAI, assistente Bitcoin da Rádio BitAdict de @bitadict.
Respondes em português (PT-BR), de forma concisa (máx 3 frases).
És um Bitcoiner convicto: defends autocustódia, Lightning Network, código aberto.
Contexto atual: BTC=${price}, Fear & Greed={fear} ({fear_lbl}).
Nunca recomendas altcoins. Nunca dás conselho financeiro específico."""

    async def processar(self, pergunta: str, user: str = "anon") -> str:
        if not ANTHROPIC_KEY:
            return self._fallback(pergunta)

        system = self.SYSTEM_PROMPT.format(
            price=f"{estado['btc_price']:,.0f}",
            fear=estado["fear_index"],
            fear_lbl=estado["fear_label"],
        )

        try:
            r = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": ANTHROPIC_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                json={
                    "model": "claude-haiku-4-5-20251001",
                    "max_tokens": 200,
                    "system": system,
                    "messages": [{"role": "user", "content": pergunta}],
                },
                timeout=15,
            )
            d = r.json()
            return d["content"][0]["text"] if r.ok else self._fallback(pergunta)
        except Exception as e:
            self.log.warning(f"Chat: {e}")
            return self._fallback(pergunta)

    def _fallback(self, pergunta: str) -> str:
        p = pergunta.lower()
        if "preço" in p or "price" in p or "btc" in p:
            return f"BTC está a ${estado['btc_price']:,.0f} agora. Fear & Greed: {estado['fear_label']}. Stack sats!"
        if "halving" in p:
            return "O halving ocorre a cada 210.000 blocos (~4 anos), reduzindo a emissão de BTC pela metade. Deflação programada."
        if "lightning" in p:
            return "Lightning Network permite pagamentos Bitcoin instantâneos com taxas de frações de centavo. O futuro dos pagamentos."
        if "carteira" in p or "wallet" in p:
            return "Autocustódia é soberania. Hardware wallet (Coldcard, Trezor) para stacks grandes. Nunca deixes BTC em exchange."
        return f"Bitcoin: ${estado['btc_price']:,.0f} | Fear: {estado['fear_label']} | Stack sats todos os dias. 🚀"

# ══════════════════════════════════════════════════════════════════
#  AGENTE 5 — ZAP AGENT
#  Processa doações Lightning e mantém leaderboard
# ══════════════════════════════════════════════════════════════════

class ZapAgent:
    NAME = "ZapAgent"
    log  = logging.getLogger("ZapAgent")

    def __init__(self):
        self.leaderboard = carregar_json(LEADERBOARD_FILE, [])

    async def processar_zap(self, zap_info: dict):
        """Processa um zap recebido."""
        amount = zap_info.get("amount", 0)
        sender = zap_info.get("from", "Anónimo")[:16]
        message = zap_info.get("message", "")

        if amount < MIN_ZAP_SATS:
            return

        # Atualiza leaderboard
        entry = next((e for e in self.leaderboard if e["name"] == sender), None)
        if entry:
            entry["sats"] += amount
            entry["zaps"] += 1
        else:
            self.leaderboard.append({"name": sender, "sats": amount, "zaps": 1, "first": int(time.time())})

        self.leaderboard.sort(key=lambda x: x["sats"], reverse=True)
        self.leaderboard = self.leaderboard[:50]
        salvar_json(LEADERBOARD_FILE, self.leaderboard)

        # Broadcast
        await broadcast_ws({
            "type":        "zap_received",
            "agent":       self.NAME,
            "amount":      amount,
            "from":        sender,
            "message":     message,
            "leaderboard": self.leaderboard[:10],
        })

        # Lê mensagem na rádio se ≥ MIN_ZAP_SATS
        if message and amount >= MIN_ZAP_SATS:
            await broadcast_ws({
                "type":    "tts_request",
                "agent":   self.NAME,
                "text":    f"Zap de {amount} sats de {sender}: {message}",
                "priority": "high",
            })

        msg = f"⚡ *Zap recebido!*\n{amount} sats de `{sender}`\n{message}"
        enviar_telegram(msg)
        self.log.info(f"Zap: {amount} sats de {sender}")

# ══════════════════════════════════════════════════════════════════
#  AGENTE 6 — NOSTR AGENT
#  Escuta contribuições via Nostr
# ══════════════════════════════════════════════════════════════════

class NostrAgent:
    NAME = "NostrAgent"
    log  = logging.getLogger("NostrAgent")

    def __init__(self, zap_agent: ZapAgent):
        self.zap_agent = zap_agent
        self.seen_events = set()

    async def run(self):
        self.log.info("NostrAgent iniciado")
        tasks = [asyncio.create_task(self._listen(relay)) for relay in NOSTR_RELAYS]
        await asyncio.gather(*tasks, return_exceptions=True)

    async def _listen(self, relay_url: str):
        import websockets
        backoff = 5
        while True:
            try:
                async with websockets.connect(relay_url, ping_interval=30, ping_timeout=10) as ws:
                    self.log.info(f"Conectado: {relay_url}")
                    backoff = 5

                    # Subscrição para #RadioBitadict
                    sub = {"kinds": [1, 9735], "limit": 50, "#t": ["RadioBitadict", "radiobitadict"]}
                    await ws.send(json.dumps(["REQ", "radio_sub", sub]))

                    async for raw in ws:
                        try:
                            msg = json.loads(raw)
                            if msg[0] == "EVENT" and len(msg) >= 3:
                                await self._processar_evento(msg[2])
                        except Exception:
                            pass

            except Exception as e:
                self.log.warning(f"{relay_url}: {e} — retry em {backoff}s")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 120)

    async def _processar_evento(self, event: dict):
        eid = event.get("id", "")
        if eid in self.seen_events:
            return
        self.seen_events.add(eid)
        if len(self.seen_events) > 1000:
            self.seen_events = set(list(self.seen_events)[-500:])

        kind = event.get("kind", 0)
        content = event.get("content", "")
        pubkey = event.get("pubkey", "")[:12]

        # Kind 9735 = Zap
        if kind == 9735:
            zap_info = self._parse_zap(event)
            if zap_info:
                await self.zap_agent.processar_zap(zap_info)
            return

        # Kind 1 = Nota normal
        if kind == 1 and content:
            tags = event.get("tags", [])

            # Submissão de música
            if any(t[0] == "t" and t[1].lower() in ["musicabitcoin", "bitcoinmusic"] for t in tags if len(t) > 1):
                await self._processar_musica(content, pubkey, event)
                return

            # Submissão de código
            if any(t[0] == "t" and t[1].lower() in ["radiobitadict-code", "bitadict-pr"] for t in tags if len(t) > 1):
                await self._processar_codigo(content, pubkey)
                return

            # Mensagem geral para a rádio
            await broadcast_ws({
                "type":    "nostr_note",
                "agent":   self.NAME,
                "content": content[:280],
                "author":  pubkey,
                "time":    event.get("created_at", int(time.time())),
            })

    def _parse_zap(self, event: dict) -> dict | None:
        amount, sender, message = 0, None, ""
        for tag in event.get("tags", []):
            if tag[0] == "amount" and len(tag) > 1:
                try:
                    amount = int(tag[1]) // 1000  # msats → sats
                except Exception:
                    pass
            elif tag[0] == "p" and len(tag) > 1:
                sender = tag[1][:12]
            elif tag[0] == "description" and len(tag) > 1:
                try:
                    desc = json.loads(tag[1])
                    message = desc.get("content", "")
                except Exception:
                    message = tag[1]
        if amount >= MIN_ZAP_SATS:
            return {"amount": amount, "from": sender or "Anónimo", "message": message}
        return None

    async def _processar_musica(self, content: str, pubkey: str, event: dict):
        """Coloca música na fila de aprovação."""
        item = {
            "type":      "music_submission",
            "content":   content[:500],
            "author":    pubkey,
            "event_id":  event.get("id", "")[:16],
            "timestamp": int(time.time()),
            "status":    "pending",
        }
        queue = carregar_json(MUSIC_QUEUE_FILE, [])
        queue.insert(0, item)
        salvar_json(MUSIC_QUEUE_FILE, queue[:20])

        await broadcast_ws({"type": "music_submission", "agent": self.NAME, **item})
        self.log.info(f"Música submetida por {pubkey}")

    async def _processar_codigo(self, content: str, pubkey: str):
        """Regista contribuição de código."""
        await broadcast_ws({
            "type":    "code_submission",
            "agent":   self.NAME,
            "content": content[:300],
            "author":  pubkey,
            "time":    int(time.time()),
        })
        enviar_telegram(f"📝 *Código submetido via Nostr*\nAutor: `{pubkey}`\n{content[:100]}...")
        self.log.info(f"Código de {pubkey}")

# ══════════════════════════════════════════════════════════════════
#  WEBSOCKET SERVER — Gateway para o frontend
# ══════════════════════════════════════════════════════════════════

chat_agent_instance = ChatAgent()

async def ws_handler(websocket, path=None):
    import websockets
    estado["ws_clients"].add(websocket)
    logging.info(f"WS cliente conectado. Total: {len(estado['ws_clients'])}")

    # Snapshot inicial
    try:
        await websocket.send(json.dumps({
            "type":        "snapshot",
            "btc_price":   estado["btc_price"],
            "btc_change":  estado["btc_change"],
            "fear":        estado["fear_index"],
            "fear_lbl":    estado["fear_label"],
            "block":       estado["block_height"],
            "leaderboard": carregar_json(LEADERBOARD_FILE, [])[:10],
            "news":        carregar_json(NEWS_CACHE_FILE, [])[:5],
            "music_queue": carregar_json(MUSIC_QUEUE_FILE, [])[:3],
            "content":     carregar_json(QUEUE_FILE, [])[:20],
        }))
    except Exception:
        pass

    try:
        async for raw in websocket:
            try:
                msg = json.loads(raw)
                await _handle_ws_message(msg, websocket)
            except Exception as e:
                logging.warning(f"WS msg: {e}")
    except Exception:
        pass
    finally:
        estado["ws_clients"].discard(websocket)
        logging.info(f"WS cliente desconectado. Total: {len(estado['ws_clients'])}")


async def _handle_ws_message(msg: dict, ws):
    t = msg.get("type")

    if t == "chat":
        pergunta = msg.get("text", "")[:200]
        if pergunta:
            resposta = await chat_agent_instance.processar(pergunta, msg.get("user", "anon"))
            await ws.send(json.dumps({"type": "chat_response", "text": resposta, "agent": "ChatAgent"}))

    elif t == "content_submission":
        title = msg.get("title", "")[:120]
        link  = msg.get("link",  "")[:320]
        if title and link:
            item = {"type": "content_submission", "title": title, "link": link,
                    "note": msg.get("note","")[:240], "clientId": msg.get("clientId",""),
                    "timestamp": int(time.time())}
            queue = carregar_json(QUEUE_FILE, [])
            queue.insert(0, item); queue = queue[:40]
            salvar_json(QUEUE_FILE, queue)
            await broadcast_ws(item)

    elif t == "request_leaderboard":
        await ws.send(json.dumps({
            "type":        "leaderboard_update",
            "leaderboard": carregar_json(LEADERBOARD_FILE, [])[:10],
        }))

# ══════════════════════════════════════════════════════════════════
#  AGENTE AUXILIAR — Fear & Greed + Block height
# ══════════════════════════════════════════════════════════════════

async def fetch_auxiliares():
    while True:
        try:
            # Fear & Greed
            r = requests.get("https://api.alternative.me/fng/", timeout=10)
            if r.ok:
                d = r.json()["data"][0]
                estado["fear_index"] = int(d["value"])
                estado["fear_label"] = d["value_classification"]
        except Exception:
            pass

        try:
            # Block height
            r = requests.get("https://mempool.space/api/blocks/tip/height", timeout=10)
            if r.ok:
                estado["block_height"] = int(r.json())
        except Exception:
            pass

        await asyncio.sleep(300)

# ══════════════════════════════════════════════════════════════════
#  MAIN — Orquestrador
# ══════════════════════════════════════════════════════════════════

async def main():
    import websockets

    print("""
╔══════════════════════════════════════════════════════════════════╗
║   ⚡ RÁDIO BITADICT — AGENTES AUTÓNOMOS V1.0                    ║
║   Open Source | Nostr + Lightning | @bitadict                   ║
╚══════════════════════════════════════════════════════════════════╝
    """)

    # Instancia agentes
    market_agent = MarketAgent()
    news_agent   = NewsAgent()
    music_agent  = MusicAgent()
    zap_agent    = ZapAgent()
    nostr_agent  = NostrAgent(zap_agent)

    # Servidor WebSocket
    server = await websockets.serve(ws_handler, "0.0.0.0", WS_PORT)
    print(f"[WS] Servidor em ws://localhost:{WS_PORT}")

    # Roda todos os agentes em paralelo
    await asyncio.gather(
        market_agent.run(),
        news_agent.run(),
        music_agent.run(),
        nostr_agent.run(),
        fetch_auxiliares(),
        return_exceptions=True,
    )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[BOOT] Agentes encerrados.")
