# ⚡ RÁDIO BITADICT — PROTOCOLO OPEN SOURCE V1.0

> **A primeira rádio Bitcoin com swarm de agentes autónomos, governada pela comunidade via Nostr + Lightning.**

---

## 🌐 O que é isto?

A Rádio BitAdict é um projecto open source onde:

- **Agentes de IA autónomos** monitoram o mercado, geram notícias TTS, compõem letras Bitcoin
- **Qualquer pessoa** pode contribuir via Nostr + Lightning
- **Doações em sats** dão voz na rádio e aparecem no leaderboard ao vivo
- **Músicas submetidas** pela comunidade entram na playlist via aprovação
- **Código** pode ser contribuído via Nostr com tag `#radiobitadict-code`

---

## 🤖 Agentes Autónomos

| Agente | Função | Intervalo |
|--------|--------|-----------|
| `MarketAgent` | Preços BTC ao vivo + comentários de mercado | 30s / 10min |
| `NewsAgent` | Notícias Bitcoin + TTS em PT-BR | 30min |
| `MusicAgent` | Gera letras Bitcoin com Claude AI | 1h |
| `ChatAgent` | Responde perguntas com contexto real | On-demand |
| `ZapAgent` | Processa Lightning zaps + leaderboard | Real-time |
| `NostrAgent` | Escuta contribuições via Nostr relays | Real-time |

---

## 🚀 Como Contribuir

### Via Nostr

1. Publica uma nota com `#RadioBitadict`
2. Para submeter música: adiciona tag `#bitcoinmusic`
3. Para submeter código: adiciona tag `#radiobitadict-code`
4. Zap a nota para ela ser lida ao vivo na rádio

### Via Lightning

Envia sats para: **texugorecords@walletofsatoshi.com**

- ≥ 21 sats → mensagem lida na rádio
- ≥ 210 sats → destaque no leaderboard 24h
- ≥ 2100 sats → nome permanente no hall of fame

### Via GitHub

```bash
git clone https://github.com/bitadict/radio-bitadict
cd radio-bitadict
pip install -r requirements.txt
cp .env.example .env
# Edita o .env com as tuas chaves
python radio_agents.py
```

---

## 🛠️ Setup

### Requisitos

```
Python 3.11+
pip install requests gtts websockets python-dotenv anthropic
```

### .env

```env
# Obrigatório
LIGHTNING_ADDRESS=texugorecords@walletofsatoshi.com

# Opcional — activa Chat IA real
ANTHROPIC_API_KEY=sk-ant-...

# Opcional — notificações
TELEGRAM_TOKEN=...
TELEGRAM_CHAT_ID=...

# Configuração
WS_PORT=8765
MIN_ZAP_SATS=21
```

### Arrancar

```bash
# Apenas os agentes
python radio_agents.py

# Com a rádio (frontend)
# Copia index.html + músicas para pasta pública
# Serve com qualquer servidor HTTP
python -m http.server 3000
```

---

## 📡 Protocolo WebSocket

O sistema expõe um WebSocket em `ws://localhost:8765`.

### Mensagens do servidor → cliente

```json
// Preço BTC actualizado
{"type": "market_update", "price": 85000, "change": 2.3}

// Notícia Bitcoin
{"type": "news_update", "items": [{"title": "...", "url": "..."}]}

// TTS pronto para tocar
{"type": "tts_ready", "text": "...", "file": "radio_dados/tts_latest.mp3"}

// Zap recebido
{"type": "zap_received", "amount": 210, "from": "npub1...", "message": "..."}

// Nota Nostr
{"type": "nostr_note", "content": "...", "author": "npub1..."}

// Letra gerada por IA
{"type": "music_generation", "lyrics": "...", "prompt": "..."}

// Leaderboard actualizado
{"type": "leaderboard_update", "leaderboard": [...]}
```

### Mensagens cliente → servidor

```json
// Chat com BITAI
{"type": "chat", "text": "Qual é o preço do BTC?"}

// Submeter conteúdo
{"type": "content_submission", "title": "...", "link": "...", "note": "..."}

// Pedir leaderboard
{"type": "request_leaderboard"}
```

---

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────┐
│                  RÁDIO BITADICT                  │
│                                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────────┐  │
│  │  Nostr   │  │Lightning │  │  CoinGecko   │  │
│  │  Relays  │  │  Zaps    │  │  Mempool API │  │
│  └────┬─────┘  └────┬─────┘  └──────┬───────┘  │
│       │             │               │           │
│  ┌────▼─────────────▼───────────────▼───────┐  │
│  │           SWARM DE AGENTES               │  │
│  │  NostrAgent  ZapAgent  MarketAgent       │  │
│  │  NewsAgent   MusicAgent  ChatAgent       │  │
│  └─────────────────────┬─────────────────────┘  │
│                        │ WebSocket               │
│  ┌─────────────────────▼─────────────────────┐  │
│  │              FRONTEND                     │  │
│  │  Player  BTC Price  Leaderboard  Chat     │  │
│  │  Nostr Feed  Music Queue  TTS             │  │
│  └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
```

---

## 📜 Licença

MIT — Usa, modifica e distribui livremente.
Crédito a @bitadict apreciado mas não obrigatório.

---

## ⚡ Suporte ao Projecto

**Lightning:** texugorecords@walletofsatoshi.com  
**Nostr:** @bitadict  
**GitHub:** github.com/bitadict/radio-bitadict

> *"A rádio que não pode ser censurada, porque não tem dono — tem comunidade."*
> — @bitadict
