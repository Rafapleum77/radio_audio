"""
Endpoints de analytics (plays, shares, usuários, revenue).
"""
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from app.models.database import get_db
from app.models.models import AnalyticsEvent, User, Subscription, Bulletin, AffiliateLink, Sponsor
from app.core.security import get_admin_user
from app.models.models import User as UserModel
from app.schemas.schemas import AnalyticsSummary, AnalyticsEventResponse

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/summary", response_model=AnalyticsSummary)
def get_summary(
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
):
    """Resumo geral de analytics para o período."""
    since = datetime.utcnow() - timedelta(days=days)

    total_plays = db.query(AnalyticsEvent).filter(
        AnalyticsEvent.event_type == "play",
        AnalyticsEvent.created_at >= since,
    ).count()

    total_shares = db.query(AnalyticsEvent).filter(
        AnalyticsEvent.event_type == "share",
        AnalyticsEvent.created_at >= since,
    ).count()

    total_users = db.query(User).count()
    active_subs = db.query(Subscription).filter(Subscription.status == "active").count()
    total_bulletins = db.query(Bulletin).filter(Bulletin.status == "published").count()

    # Top bulletin
    top_bulletin = db.query(
        AnalyticsEvent.content_id,
        func.count(AnalyticsEvent.id),
    ).filter(
        AnalyticsEvent.event_type == "play",
        AnalyticsEvent.content_type == "bulletin",
        AnalyticsEvent.created_at >= since,
    ).group_by(AnalyticsEvent.content_id).order_by(
        desc(func.count(AnalyticsEvent.id))
    ).first()

    return AnalyticsSummary(
        total_plays=total_plays,
        total_shares=total_shares,
        total_users=total_users,
        bulletins_generated=total_bulletins,
        avg_play_duration=180.0,  # Placeholder - calcular de dados reais
        top_bulletin_id=top_bulletin[0] if top_bulletin else None,
    )


@router.get("/events", response_model=list[AnalyticsEventResponse])
def list_events(
    event_type: str = Query(None),
    content_type: str = Query(None),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    """Listar eventos de analytics com filtros."""
    query = db.query(AnalyticsEvent)

    if event_type:
        query = query.filter(AnalyticsEvent.event_type == event_type)
    if content_type:
        query = query.filter(AnalyticsEvent.content_type == content_type)

    events = query.order_by(desc(AnalyticsEvent.created_at)).limit(limit).all()
    return [AnalyticsEventResponse.model_validate(e) for e in events]


@router.get("/revenue")
def get_revenue(
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
):
    """Resumo de receita (afiliados + sponsors)."""
    since = datetime.utcnow() - timedelta(days=days)

    # Afiliados
    affiliate_revenue = db.query(
        func.sum(AffiliateLink.revenue_total)
    ).filter(AffiliateLink.is_active == True).scalar() or 0.0

    affiliate_clicks = db.query(
        func.sum(AffiliateLink.click_count)
    ).filter(AffiliateLink.is_active == True).scalar() or 0

    # Sponsors
    sponsor_spend = db.query(
        func.sum(Sponsor.total_spend)
    ).filter(Sponsor.is_active == True).scalar() or 0.0

    sponsor_impressions = db.query(
        func.sum(Sponsor.total_impressions)
    ).filter(Sponsor.is_active == True).scalar() or 0

    return {
        "affiliate_revenue": float(affiliate_revenue),
        "affiliate_clicks": int(affiliate_clicks),
        "sponsor_revenue": float(sponsor_spend),
        "sponsor_impressions": int(sponsor_impressions),
        "total_revenue": float(affiliate_revenue) + float(sponsor_spend),
        "period_days": days,
    }


@router.get("/plays-by-day")
def plays_by_day(
    days: int = Query(30, ge=1, le=90),
    db: Session = Depends(get_db),
):
    """Plays por dia para os últimos N dias."""
    since = datetime.utcnow() - timedelta(days=days)

    results = db.query(
        func.date_trunc("day", AnalyticsEvent.created_at),
        func.count(AnalyticsEvent.id),
    ).filter(
        AnalyticsEvent.event_type == "play",
        AnalyticsEvent.created_at >= since,
    ).group_by(
        func.date_trunc("day", AnalyticsEvent.created_at)
    ).order_by(
        func.date_trunc("day", AnalyticsEvent.created_at)
    ).all()

    return [
        {"date": r[0].strftime("%Y-%m-%d"), "plays": r[1]}
        for r in results
    ]
