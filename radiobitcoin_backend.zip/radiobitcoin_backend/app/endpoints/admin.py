"""
Endpoints de administração (dashboard, gestão de conteúdo, afiliados, sponsors).
"""
import asyncio
from fastapi import APIRouter, Depends, BackgroundTasks
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.models.models import (
    User, Subscription, Bulletin, Podcast, PodcastEpisode,
    AffiliateLink, Sponsor, AnalyticsEvent, BulletinStatus,
)
from app.core.security import get_admin_user, get_current_user
from app.models.models import User as UserModel
from app.schemas.schemas import (
    AdminStats,
    AffiliateLinkResponse,
    SponsorResponse,
    GenerateAllRequest,
    BulletinResponse,
    UserResponse,
)

router = APIRouter(prefix="/admin", tags=["Administração"])


@router.get("/stats", response_model=AdminStats)
def get_admin_stats(
    db: Session = Depends(get_db),
    admin: UserModel = Depends(get_admin_user),
):
    """Dashboard de administração com métricas gerais."""
    total_users = db.query(User).count()
    active_subs = db.query(Subscription).filter(Subscription.status == "active").count()
    total_bulletins = db.query(Bulletin).filter(Bulletin.status == BulletinStatus.PUBLISHED).count()
    total_plays = db.query(AnalyticsEvent).filter(AnalyticsEvent.event_type == "play").count()

    affiliate_clicks = db.query(AffiliateLink).with_entities(
        __import__("sqlalchemy").func.sum(AffiliateLink.click_count)
    ).scalar() or 0

    sponsor_impressions = db.query(Sponsor).with_entities(
        __import__("sqlalchemy").func.sum(Sponsor.total_impressions)
    ).scalar() or 0

    total_revenue = db.query(AffiliateLink).with_entities(
        __import__("sqlalchemy").func.sum(AffiliateLink.revenue_total)
    ).scalar() or 0.0

    sponsor_spend = db.query(Sponsor).with_entities(
        __import__("sqlalchemy").func.sum(Sponsor.total_spend)
    ).scalar() or 0.0

    return AdminStats(
        total_users=total_users,
        active_subscribers=active_subs,
        total_bulletins=total_bulletins,
        total_plays=total_plays,
        total_revenue=float(total_revenue) + float(sponsor_spend),
        affiliate_clicks=int(affiliate_clicks),
        sponsor_impressions=int(sponsor_impressions),
    )


@router.post("/generate-all", status_code=202)
async def generate_all_bulletins_admin(
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    admin: UserModel = Depends(get_admin_user),
):
    """Gerar os 3 boletins do dia via admin."""
    from app.services.bulletin_pipeline import BulletinPipeline

    pipeline = BulletinPipeline(db)

    async def _generate_all():
        await pipeline.generate_all_daily()

    background_tasks.add_task(_generate_all)

    return {"message": "Gerando 3 boletins do dia em background"}


@router.post("/retry/{bulletin_id}")
def retry_bulletin(
    bulletin_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    admin: UserModel = Depends(get_admin_user),
):
    """Reprocessar um boletim que falhou."""
    from app.services.bulletin_pipeline import BulletinPipeline

    pipeline = BulletinPipeline(db)

    async def _retry():
        await pipeline.retry_failed_bulletin(bulletin_id)

    background_tasks.add_task(_retry)
    return {"message": f"Reprocessando boletim {bulletin_id}"}


@router.get("/users", response_model=list[UserResponse])
def list_users(
    db: Session = Depends(get_db),
    admin: UserModel = Depends(get_admin_user),
):
    """Listar todos os usuários (admin only)."""
    users = db.query(User).order_by(User.created_at.desc()).limit(100).all()
    return [UserResponse.model_validate(u) for u in users]


@router.get("/affiliates", response_model=list[AffiliateLinkResponse])
def list_affiliates(
    db: Session = Depends(get_db),
    admin: UserModel = Depends(get_admin_user),
):
    """Listar links de afiliados e performance."""
    links = db.query(AffiliateLink).filter(AffiliateLink.is_active == True).all()
    return [AffiliateLinkResponse.model_validate(a) for a in links]


@router.get("/sponsors", response_model=list[SponsorResponse])
def list_sponsors(
    db: Session = Depends(get_db),
    admin: UserModel = Depends(get_admin_user),
):
    """Listar patrocinadores e performance."""
    sponsors = db.query(Sponsor).filter(Sponsor.is_active == True).all()
    return [SponsorResponse.model_validate(s) for s in sponsors]
