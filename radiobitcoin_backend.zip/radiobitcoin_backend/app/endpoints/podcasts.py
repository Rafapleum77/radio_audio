"""
Endpoints de podcasts e episódios.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.models.database import get_db
from app.models.models import Podcast, PodcastEpisode, AnalyticsEvent
from app.core.security import get_current_user
from app.schemas.schemas import (
    PodcastCreate,
    PodcastResponse,
    PodcastEpisodeCreate,
    PodcastEpisodeResponse,
)

router = APIRouter(prefix="/podcasts", tags=["Podcasts"])


@router.get("/", response_model=list[PodcastResponse])
def list_podcasts(db: Session = Depends(get_db)):
    """Listar todos os podcasts ativos."""
    podcasts = db.query(Podcast).filter(Podcast.is_active == True).all()
    return [PodcastResponse.model_validate(p) for p in podcasts]


@router.get("/{podcast_id}", response_model=PodcastResponse)
def get_podcast(podcast_id: int, db: Session = Depends(get_db)):
    """Obter detalhes de um podcast."""
    podcast = db.query(Podcast).filter(Podcast.id == podcast_id).first()
    if not podcast:
        raise HTTPException(status_code=404, detail="Podcast não encontrado")
    return PodcastResponse.model_validate(podcast)


@router.get("/{podcast_id}/episodes", response_model=list[PodcastEpisodeResponse])
def list_episodes(
    podcast_id: int,
    page: int = Query(1, ge=1),
    per_page: int = Query(10, ge=1, le=50),
    db: Session = Depends(get_db),
):
    """Listar episódios de um podcast com paginação."""
    podcast = db.query(Podcast).filter(Podcast.id == podcast_id).first()
    if not podcast:
        raise HTTPException(status_code=404, detail="Podcast não encontrado")

    episodes = (
        db.query(PodcastEpisode)
        .filter(PodcastEpisode.podcast_id == podcast_id)
        .order_by(desc(PodcastEpisode.published_at))
        .offset((page - 1) * per_page)
        .limit(per_page)
        .all()
    )

    return [PodcastEpisodeResponse.model_validate(e) for e in episodes]


@router.get("/episodes/{episode_id}", response_model=PodcastEpisodeResponse)
def get_episode(episode_id: int, db: Session = Depends(get_db)):
    """Obter detalhes de um episódio."""
    episode = db.query(PodcastEpisode).filter(PodcastEpisode.id == episode_id).first()
    if not episode:
        raise HTTPException(status_code=404, detail="Episódio não encontrado")
    return PodcastEpisodeResponse.model_validate(episode)


@router.post("/episodes/{episode_id}/play")
def record_episode_play(
    episode_id: int,
    current_user=None,
    db: Session = Depends(get_db),
):
    """Registrar play de um episódio."""
    episode = db.query(PodcastEpisode).filter(PodcastEpisode.id == episode_id).first()
    if not episode:
        raise HTTPException(status_code=404, detail="Episódio não encontrado")

    episode.play_count += 1
    db.commit()

    event = AnalyticsEvent(
        user_id=current_user.id if current_user else None,
        event_type="play",
        content_type="podcast",
        content_id=episode_id,
    )
    db.add(event)
    db.commit()

    return {"message": "Play registrado", "total_plays": episode.play_count}
