"""
Endpoints de assinaturas (Stripe integration).
"""
import stripe
from fastapi import APIRouter, Depends, HTTPException, Request, Header
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.models.models import User, Subscription
from app.core.config import settings
from app.core.security import get_current_user
from app.schemas.schemas import SubscriptionResponse, SubscriptionCreate

router = APIRouter(prefix="/subscriptions", tags=["Assinaturas"])

# Configurar Stripe
if settings.stripe_secret_key:
    stripe.api_key = settings.stripe_secret_key

# Preço por plano (em centavos)
PLAN_PRICES = {
    "basico": "price_BASICO_ID",   # Substituir pelo ID real do Stripe
    "pro": "price_PRO_ID",         # Substituir pelo ID real do Stripe
}


@router.get("/me", response_model=SubscriptionResponse)
def get_my_subscription(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Obter a assinatura atual do usuário."""
    sub = db.query(Subscription).filter(Subscription.user_id == current_user.id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Assinatura não encontrada")
    return SubscriptionResponse.model_validate(sub)


@router.post("/create-checkout")
async def create_checkout_session(
    request: SubscriptionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Criar sessão de checkout Stripe para upgrade de plano.
    Retorna URL de checkout.
    """
    if not settings.stripe_secret_key:
        raise HTTPException(status_code=501, detail="Stripe não configurado")

    if request.plan == "free":
        raise HTTPException(status_code=400, detail="Plano free não requer checkout")

    price_id = PLAN_PRICES.get(request.plan)
    if not price_id:
        raise HTTPException(status_code=400, detail=f"Plano {request.plan} inválido")

    # Criar ou obter Stripe Customer
    sub = db.query(Subscription).filter(Subscription.user_id == current_user.id).first()
    customer_id = sub.stripe_customer_id if sub else None

    if not customer_id:
        customer = stripe.Customer.create(
            email=current_user.email,
            name=current_user.full_name,
            metadata={"user_id": str(current_user.id)},
        )
        customer_id = customer.id

        # Atualizar no banco
        if sub:
            sub.stripe_customer_id = customer_id
        db.commit()

    # Criar Checkout Session
    session = stripe.checkout.Session.create(
        customer=customer_id,
        mode="subscription",
        payment_method_types=["card"],
        line_items=[{"price": price_id, "quantity": 1}],
        success_url=f"{settings.cors_origins.split(',')[0]}/subscription/success?session_id={{CHECKOUT_SESSION_ID}}",
        cancel_url=f"{settings.cors_origins.split(',')[0]}/subscription/cancel",
        metadata={"user_id": str(current_user.id), "plan": request.plan},
    )

    return {"checkout_url": session.url, "session_id": session.id}


@router.post("/webhook")
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(None, alias="stripe-signature"),
    db: Session = Depends(get_db),
):
    """
    Webhook Stripe para eventos de assinatura.
    Atualiza status de subscription automaticamente.
    """
    if not settings.stripe_secret_key:
        raise HTTPException(status_code=501, detail="Stripe não configurado")

    body = await request.body()

    try:
        event = stripe.Webhook.construct_event(
            body,
            stripe_signature,
            settings.stripe_webhook_secret,
        )
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Assinatura inválida")

    # Processar eventos
    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        user_id = int(session["metadata"]["user_id"])
        plan = session["metadata"]["plan"]

        sub = db.query(Subscription).filter(Subscription.user_id == user_id).first()
        if sub:
            sub.plan = plan
            sub.status = "active"
            sub.stripe_subscription_id = session.get("subscription")
            db.commit()

    elif event["type"] == "customer.subscription.updated":
        stripe_sub = event["data"]["object"]
        customer_id = stripe_sub.get("customer")

        sub = db.query(Subscription).filter(
            Subscription.stripe_customer_id == customer_id
        ).first()
        if sub:
            sub.status = stripe_sub.get("status", "active")
            sub.current_period_start = stripe_sub.get("current_period_start")
            sub.current_period_end = stripe_sub.get("current_period_end")
            db.commit()

    elif event["type"] == "customer.subscription.deleted":
        stripe_sub = event["data"]["object"]
        customer_id = stripe_sub.get("customer")

        sub = db.query(Subscription).filter(
            Subscription.stripe_customer_id == customer_id
        ).first()
        if sub:
            sub.status = "canceled"
            sub.plan = "free"
            db.commit()

    return {"status": "ok"}


@router.post("/cancel")
def cancel_subscription(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Cancelar assinatura atual."""
    sub = db.query(Subscription).filter(Subscription.user_id == current_user.id).first()
    if not sub or sub.plan == "free":
        raise HTTPException(status_code=400, detail="Nenhuma assinatura ativa para cancelar")

    if sub.stripe_subscription_id:
        stripe.Subscription.modify(
            sub.stripe_subscription_id,
            cancel_at_period_end=True,
        )

    sub.status = "canceling"
    db.commit()

    return {"message": "Assinatura será cancelada ao final do período"}
