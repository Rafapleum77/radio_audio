"""
Endpoints de boletins (listar, ouvir, gerar, compartilhar).
"""
import asyncio
from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.orm import Session
from sqlalchemy import desc, func

from app.models.database import get_db
from app.models.models import Bulletin, BulletinStatus, AnalyticsEvent
from app.core.security import get_current_user
from app.schemas.schemas import (
    BulletinCreate,
    BulletinResponse,
    BulletinGenerateRequest,
    BulletinListResponse,
)

router = APIRouter(prefix="/bulletins", tags=["Boletins"])


@router.get("/", response_model=BulletinListResponse)
def list_bulletins(
    period: str = Query(None, description="Filtrar por período (manha/tarde/noite)"),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    """Listar boletins publicados com paginação."""
    query = db.query(Bulletin).filter(Bulletin.status == BulletinStatus.PUBLISHED)

    if period:
        from app.models.models import BulletinPeriod
        query = query.filter(Bulletin.period == BulletinPeriod(period))

    total = query.count()
    items = (
        query.order_by(desc(Bulletin.published_at))
        .offset((page - 1) * per_page)
        .limit(per_page)
        .all()
    )

    return BulletinListResponse(
        items=[BulletinResponse.model_validate(b) for b in items],
        total=total,
        page=page,
        per_page=per_page,
    )


@router.get("/latest", response_model=BulletinResponse)
def get_latest_bulletin(
    period: str = Query(None),
    db: Session = Depends(get_db),
):
    """Obter o boletim mais recente (opcionalmente de um período específico)."""
    query = db.query(Bulletin).filter(Bulletin.status == BulletinStatus.PUBLISHED)

    if period:
        from app.models.models import BulletinPeriod
        query = query.filter(Bulletin.period == BulletinPeriod(period))

    bulletin = query.order_by(desc(Bulletin.published_at)).first()
    if not bulletin:
        raise HTTPException(status_code=404, detail="Nenhum boletim encontrado")

    return BulletinResponse.model_validate(bulletin)


@router.get("/{bulletin_id}", response_model=BulletinResponse)
def get_bulletin(
    bulletin_id: int,
    db: Session = Depends(get_db),
):
    """Obter detalhes de um boletim específico."""
    bulletin = db.query(Bulletin).filter(Bulletin.id == bulletin_id).first()
    if not bulletin or bulletin.status != BulletinStatus.PUBLISHED:
        raise HTTPException(status_code=404, detail="Boletim não encontrado")

    return BulletinResponse.model_validate(bulletin)


@router.post("/{bulletin_id}/play")
def record_play(
    bulletin_id: int,
    current_user=None,
    db: Session = Depends(get_db),
):
    """Registrar play do boletim e incrementar contador."""
    bulletin = db.query(Bulletin).filter(Bulletin.id == bulletin_id).first()
    if not bulletin:
        raise HTTPException(status_code=404, detail="Boletim não encontrado")

    bulletin.play_count += 1
    db.commit()

    # Registrar evento de analytics (anônimo se não logado)
    event = AnalyticsEvent(
        user_id=current_user.id if current_user else None,
        event_type="play",
        content_type="bulletin",
        content_id=bulletin_id,
    )
    db.add(event)
    db.commit()

    return {"message": "Play registrado", "total_plays": bulletin.play_count}


@router.post("/{bulletin_id}/share")
def record_share(
    bulletin_id: int,
    db: Session = Depends(get_db),
):
    """Registrar share do boletim."""
    bulletin = db.query(Bulletin).filter(Bulletin.id == bulletin_id).first()
    if not bulletin:
        raise HTTPException(status_code=404, detail="Boletim não encontrado")

    bulletin.share_count += 1
    db.commit()
    return {"message": "Share registrado", "total_shares": bulletin.share_count}


@router.post("/generate", status_code=202)
async def generate_bulletin(
    request: BulletinGenerateRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    """
    Gerar um novo boletim com IA (assíncrono).
    Retorna 202 Accepted e processa em background.
    """
    from app.services.bulletin_pipeline import BulletinPipeline

    # Iniciar em background para não bloquear
    pipeline = BulletinPipeline(db)

    async def _generate():
        try:
            await pipeline.generate_bulletin(
                period=request.period.value,
                auto_publish=request.auto_publish,
            )
        except Exception as e:
            print(f"Erro ao gerar boletim: {e}")

    background_tasks.add_task(_generate)

    return {
        "message": f"Boletim {request.period.value} em geração",
        "status": "accepted",
        "check_at": "/api/v1/bulletins/latest?period=" + request.period.value,
    }


@router.post("/generate-all", status_code=202)
async def generate_all_bulletins(
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    """Gerar os 3 boletins do dia (manhã, tarde, noite)."""
    from app.services.bulletin_pipeline import BulletinPipeline

    pipeline = BulletinPipeline(db)

    async def _generate_all():
        await pipeline.generate_all_daily()

    background_tasks.add_task(_generate_all)

    return {
        "message": "Gerando 3 boletins do dia",
        "status": "accepted",
        "check_at": "/api/v1/bulletins/?per_page=3",
    }
