"""
API Router v1 - Agrega todos os módulos de endpoints.
"""
from fastapi import APIRouter

from app.endpoints import auth, bulletins, podcasts, subscriptions, analytics, admin

api_v1_router = APIRouter()

# Registrar todos os módulos
api_v1_router.include_router(auth.router)
api_v1_router.include_router(bulletins.router)
api_v1_router.include_router(podcasts.router)
api_v1_router.include_router(subscriptions.router)
api_v1_router.include_router(analytics.router)
api_v1_router.include_router(admin.router)
