"""
Pydantic schemas para validação e serialização de dados da API.
"""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field
from enum import Enum


class BulletinPeriodEnum(str, Enum):
    manha = "manha"
    tarde = "tarde"
    noite = "noite"


class BulletinStatusEnum(str, Enum):
    draft = "draft"
    generating = "generating"
    ready = "ready"
    published = "published"
    failed = "failed"


# ==================== AUTH ====================

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    full_name: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: int
    email: str
    full_name: Optional[str] = None
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


# ==================== BULLETINS ====================

class BulletinCreate(BaseModel):
    period: BulletinPeriodEnum
    title: Optional[str] = None
    auto_publish: bool = True


class BulletinResponse(BaseModel):
    id: int
    title: str
    period: str
    status: str
    script_text: Optional[str] = None
    transcript: Optional[str] = None
    audio_url: Optional[str] = None
    audio_duration: Optional[float] = None
    thumbnail_url: Optional[str] = None
    play_count: int = 0
    share_count: int = 0
    created_at: datetime
    published_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class BulletinListResponse(BaseModel):
    items: List[BulletinResponse]
    total: int
    page: int
    per_page: int


class BulletinGenerateRequest(BaseModel):
    period: BulletinPeriodEnum = BulletinPeriodEnum.manha
    auto_publish: bool = True


class BulletinList(BaseModel):
    bulletins: List[BulletinResponse]
    total: int


# ==================== PODCASTS ====================

class PodcastCreate(BaseModel):
    title: str
    description: Optional[str] = None


class PodcastEpisodeCreate(BaseModel):
    podcast_id: int
    title: str
    description: Optional[str] = None


class PodcastResponse(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    cover_url: Optional[str] = None
    is_active: bool
    total_episodes: int
    created_at: datetime

    class Config:
        from_attributes = True


class PodcastEpisodeResponse(BaseModel):
    id: int
    podcast_id: int
    title: str
    description: Optional[str] = None
    audio_url: Optional[str] = None
    audio_duration: Optional[float] = None
    thumbnail_url: Optional[str] = None
    play_count: int = 0
    published_at: datetime

    class Config:
        from_attributes = True


# ==================== SUBSCRIPTIONS ====================

class SubscriptionCreate(BaseModel):
    plan: str = Field(..., pattern="^(free|basico|pro)$")


class SubscriptionResponse(BaseModel):
    id: int
    user_id: int
    plan: str
    status: str
    current_period_start: Optional[datetime] = None
    current_period_end: Optional[datetime] = None

    class Config:
        from_attributes = True


# ==================== ANALYTICS ====================

class AnalyticsEventCreate(BaseModel):
    event_type: str
    content_type: Optional[str] = None
    content_id: Optional[int] = None


class AnalyticsSummary(BaseModel):
    total_plays: int
    total_shares: int
    total_users: int
    bulletins_generated: int
    avg_play_duration: Optional[float] = None
    top_bulletin_id: Optional[int] = None


class AnalyticsEventResponse(BaseModel):
    id: int
    event_type: str
    content_type: Optional[str] = None
    content_id: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True


# ==================== COMMENTS ====================

class CommentCreate(BaseModel):
    bulletin_id: Optional[int] = None
    podcast_episode_id: Optional[int] = None
    text: str = Field(..., min_length=1, max_length=2000)


class CommentResponse(BaseModel):
    id: int
    text: str
    user_id: int
    is_approved: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ==================== ADMIN ====================

class AdminStats(BaseModel):
    total_users: int
    active_subscribers: int
    total_bulletins: int
    total_plays: int
    total_revenue: float
    affiliate_clicks: int
    sponsor_impressions: int


class AffiliateLinkResponse(BaseModel):
    id: int
    partner: str
    url: str
    commission_rate: float
    click_count: int
    conversion_count: int
    revenue_total: float
    is_active: bool

    class Config:
        from_attributes = True


class SponsorResponse(BaseModel):
    id: int
    name: str
    ad_audio_url: Optional[str] = None
    cpm_rate: float
    total_impressions: int
    total_spend: float
    is_active: bool

    class Config:
        from_attributes = True


class GenerateAllRequest(BaseModel):
    """Para gerar os 3 boletins do dia de uma vez."""
    periods: Optional[List[BulletinPeriodEnum]] = None
