"""
Serviço de geração de roteiro de boletim com IA (OpenAI/GPT).
Gera textos no estilo de rádio com tom adequado ao período do dia.
"""
import logging
from typing import List, Optional

from openai import OpenAI

from app.core.config import settings
from app.services.news_fetcher import NewsItem

logger = logging.getLogger(__name__)


class ScriptGenerator:
    """Gera roteiros de boletins de rádio com IA."""

    # Tons por período do dia
    TONE_PROFILES = {
        "manha": {
            "description": "energético e informativo",
            "instructions": "Use um tom animado e motivador. Frases curtas e diretas. Comece com energia para acordar o ouvinte. Destaque as notícias quentes do momento.",
            "greeting": "Bom dia, ouvintes da Rádio Bitcoin! Aqui é o seu boletim da manhã",
            "closing": "E é isso aí! Bora pro dia com Bitcoin na veia. Rádio Bitcoin, a sua dose diária de cripto!",
        },
        "tarde": {
            "description": "analítico e profundo",
            "instructions": "Use um tom analítico e profissional. Aprofunde nos dados e tendências. Conecte as notícias ao cenário macroeconômico. Dê contexto e perspectiva.",
            "greeting": "Boa tarde! Aqui é o boletim vespertino da Rádio Bitcoin",
            "closing": "É isso! Continue acompanhando o mercado e até o próximo boletim. Rádio Bitcoin, informação cripto com profundidade!",
        },
        "noite": {
            "description": "relaxado e resumido",
            "instructions": "Use um tom mais descontraído e reflexivo. Faça um balanço do dia. Prepare o ouvinte para o dia seguinte. Seja conciso.",
            "greeting": "Boa noite, pessoal! Chegou o resumo do dia na Rádio Bitcoin",
            "closing": "É isso, gente! Descansa que amanhã tem mais. Boa noite e bons trades! Rádio Bitcoin, sempre com você.",
        },
    }

    def __init__(self):
        self.openai = OpenAI(api_key=settings.openai_api_key) if settings.openai_api_key else None

    def generate_script(
        self,
        news_items: List[NewsItem],
        period: str = "manha",
        target_duration_minutes: float = 4.0,
    ) -> str:
        """
        Gera o roteiro completo do boletim.

        Args:
            news_items: Lista de notícias ranqueadas (máx 5)
            period: manha, tarde ou noite
            target_duration_minutes: Duração alvo em minutos (3-5 min)

        Returns:
            Texto do roteiro pronto para TTS
        """
        if not self.openai:
            raise RuntimeError("OpenAI API key não configurada")

        tone = self.TONE_PROFILES.get(period, self.TONE_PROFILES["manha"])

        # Preparar notícias para o prompt
        news_text = "\n".join([
            f"- {item.title}" + (f" (fonte: {item.source})" if item.source else "")
            for item in news_items
        ])

        # Estimativa de palavras por minuto (rádio PT-BR = ~150 palavras/min)
        target_words = int(target_duration_minutes * 150)

        system_prompt = f"""
Você é o roteirista chefe da Rádio Bitcoin, uma rádio digital dedicada ao ecossistema Bitcoin e criptomoedas.
Seu público é entusiasta de Bitcoin, com conhecimento intermediário sobre cripto.

Sua tarefa é escrever um roteiro de boletim de rádio com aproximadamente {target_words} palavras.

REGRAS:
1. {tone['instructions']}
2. Comece com: "{tone['greeting']}"
3. Termine com: "{tone['closing']}"
4. Apresente as notícias de forma fluida, como uma conversa natural
5. Use conectivos entre as notícias ("Falando de mercado...", "E no mundo das stablecoins...", "Agora, olha só isso...")
6. Não use markdown, hashtags ou formatação especial
7. Escreva números por extenso quando necessário para boa pronúncia
8. Mantenha o tom positivo e otimista sobre Bitcoin (HODL mentality)
9. Nunca dê advice financeiro direto - sempre contextualize como informação
10. Se houver dados de preço, mencione de forma natural ("o Bitcoin está na casa dos X mil dólares")

NOTÍCIAS DO DIA:
{news_text}

Escreva o roteiro completo agora:
"""

        try:
            response = self.openai.chat.completions.create(
                model=settings.openai_model,
                messages=[
                    {"role": "system", "content": "Você é o roteirista da Rádio Bitcoin. Escreva roteiros de rádio em português brasileiro."},
                    {"role": "user", "content": system_prompt},
                ],
                temperature=0.7,
                max_tokens=4000,
            )
            return response.choices[0].message.content.strip()

        except Exception as e:
            logger.error(f"Erro ao gerar roteiro: {e}")
            raise
