"""
Serviço de Text-to-Speech usando ElevenLabs.
Converte o roteiro gerado pela IA em áudio profissional.
"""
import io
import logging
from typing import Optional

import httpx
from pydub import AudioSegment

from app.core.config import settings

logger = logging.getLogger(__name__)


class TTSService:
    """Síntese de voz com ElevenLabs."""

    BASE_URL = "https://api.elevenlabs.io/v1"

    def __init__(self):
        self.api_key = settings.elevenlabs_api_key

    @property
    def headers(self) -> dict:
        return {
            "xi-api-key": self.api_key,
            "Content-Type": "application/json",
        }

    async def synthesize(
        self,
        text: str,
        voice_id: Optional[str] = None,
        model_id: Optional[str] = None,
        stability: float = 0.5,
        similarity_boost: float = 0.75,
    ) -> bytes:
        """
        Converte texto em áudio MP3 usando ElevenLabs.

        Args:
            text: Texto do roteiro
            voice_id: ID da voz ElevenLabs (default: settings)
            model_id: Modelo de voz (default: eleven_multilingual_v2)
            stability: Estabilidade da voz (0-1)
            similarity_boost: Similaridade à voz original (0-1)

        Returns:
            Bytes do áudio MP3
        """
        if not self.api_key:
            raise RuntimeError("ElevenLabs API key não configurada")

        voice_id = voice_id or settings.elevenlabs_voice_id
        model_id = model_id or settings.elevenlabs_model

        # ElevenLabs tem limite de 5000 chars por request
        # Se o texto for muito longo, dividimos em chunks
        chunks = self._split_text(text, max_chars=4000)
        audio_segments = []

        async with httpx.AsyncClient(timeout=120.0) as client:
            for chunk in chunks:
                payload = {
                    "text": chunk,
                    "model_id": model_id,
                    "voice_settings": {
                        "stability": stability,
                        "similarity_boost": similarity_boost,
                        "style": 0.5,
                        "use_speaker_boost": True,
                    },
                }

                url = f"{self.BASE_URL}/text-to-speech/{voice_id}"
                response = await client.post(
                    url,
                    headers=self.headers,
                    json=payload,
                )
                response.raise_for_status()
                audio_data = response.content
                audio_segments.append(AudioSegment.from_mp3(io.BytesIO(audio_data)))

        # Concatenar todos os segmentos
        if len(audio_segments) == 1:
            return audio_segments[0].export(format="mp3").read()

        combined = audio_segments[0]
        for seg in audio_segments[1:]:
            combined = combined.append(seg, crossfade=100)  # 100ms crossfade

        return combined.export(format="mp3", bitrate="192k").read()

    def _split_text(self, text: str, max_chars: int = 4000) -> list:
        """Divide o texto em chunks respeitando limites de sentenças."""
        if len(text) <= max_chars:
            return [text]

        chunks = []
        current = ""

        sentences = text.replace("\n", " ").split(". ")

        for sentence in sentences:
            test = f"{current}{sentence}. " if current else f"{sentence}. "
            if len(test) > max_chars and current:
                chunks.append(current.strip())
                current = f"{sentence}. "
            else:
                current = test

        if current.strip():
            chunks.append(current.strip())

        return chunks if chunks else [text]

    async def synthesize_with_music(
        self,
        script: str,
        period: str = "manha",
    ) -> bytes:
        """
        Gera o áudio completo com intro, conteúdo e outro.

        Args:
            script: Roteiro completo
            period: Período do boletim (para escolher intro adequada)

        Returns:
            Bytes do áudio final mixado
        """
        # 1. Gerar a voz
        voice_audio = await self.synthesize(script)

        # 2. Carregar intro e outro
        intro = self._load_audio(settings.ffmpeg_intro_path)
        outro = self._load_audio(settings.ffmpeg_outro_path)

        # 3. Montar sequência: intro -> voz -> outro
        voice_seg = AudioSegment.from_mp3(io.BytesIO(voice_audio))

        # Fade in/out na voz
        voice_seg = voice_seg.fade_in(500).fade_out(1000)

        # Montar
        result = AudioSegment.empty()
        if intro:
            result = result + intro
        result = result + voice_seg
        if outro:
            # Crossfade com o outro
            result = result.append(outro, crossfade=500)

        return result.export(format="mp3", bitrate="192k").read()

    def _load_audio(self, path: str) -> Optional[AudioSegment]:
        """Carrega um arquivo de áudio, retorna None se não existir."""
        try:
            return AudioSegment.from_mp3(path)
        except FileNotFoundError:
            logger.warning(f"Arquivo de áudio não encontrado: {path}")
            return None
        except Exception as e:
            logger.warning(f"Erro ao carregar {path}: {e}")
            return None

    async def get_audio_duration(self, audio_bytes: bytes) -> float:
        """Retorna a duração do áudio em segundos."""
        seg = AudioSegment.from_mp3(io.BytesIO(audio_bytes))
        return len(seg) / 1000.0
