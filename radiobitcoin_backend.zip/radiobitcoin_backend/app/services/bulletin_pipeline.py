"""
Pipeline completo de geração automática de boletins.
Orquestra: Notícias → Roteiro → TTS → Upload → Banco de dados.
"""
import asyncio
import logging
from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from app.models.models import Bulletin, BulletinPeriod, BulletinStatus
from app.services.news_fetcher import NewsFetcher
from app.services.script_generator import ScriptGenerator
from app.services.tts_service import TTSService
from app.services.storage_service import StorageService

logger = logging.getLogger(__name__)


class BulletinPipeline:
    """
    Pipeline completo de geração de boletim.
    
    Fluxo:
    1. Buscar notícias cripto (CryptoPanic + CoinGecko + Twitter)
    2. Ranquear por relevância com IA
    3. Gerar roteiro com GPT-4
    4. Sintetizar voz com ElevenLabs
    5. Mixar com intro/outro
    6. Upload para S3/R2
    7. Salvar no banco de dados
    8. Notificar assinantes
    """

    def __init__(self, db: Session):
        self.db = db
        self.news_fetcher = NewsFetcher()
        self.script_generator = ScriptGenerator()
        self.tts = TTSService()
        self.storage = StorageService()

    async def generate_bulletin(
        self,
        period: str = "manha",
        auto_publish: bool = True,
    ) -> Bulletin:
        """
        Executa o pipeline completo de geração de um boletim.

        Args:
            period: manha, tarde ou noite
            auto_publish: Se True, publica imediatamente

        Returns:
            Objeto Bulletin criado
        """
        # Criar registro no banco com status "generating"
        bulletin = Bulletin(
            title=f"Boletim {period.capitalize()} - {datetime.utcnow().strftime('%d/%m/%Y')}",
            period=BulletinPeriod(period),
            status=BulletinStatus.GENERATING,
            metadata_json={"started_at": datetime.utcnow().isoformat()},
        )
        self.db.add(bulletin)
        self.db.commit()
        self.db.refresh(bulletin)

        try:
            # === PASSO 1: Buscar notícias ===
            logger.info(f"[{bulletin.id}] Buscando notícias...")
            all_news = await self.news_fetcher.fetch_all(top_per_source=20)
            logger.info(f"[{bulletin.id}] {len(all_news)} notícias encontradas")

            # === PASSO 2: Ranquear com IA ===
            logger.info(f"[{bulletin.id}] Ranqueando por relevância...")
            top_news = await self.news_fetcher.rank_by_relevance(
                items=all_news,
                period=period,
                top_n=5,
            )
            logger.info(f"[{bulletin.id}] Top 5 selecionadas")

            # === PASSO 3: Gerar roteiro ===
            logger.info(f"[{bulletin.id}] Gerando roteiro com IA...")
            script = self.script_generator.generate_script(
                news_items=top_news,
                period=period,
                target_duration_minutes=4.0,
            )
            logger.info(f"[{bulletin.id}] Roteiro gerado ({len(script)} chars)")

            # Atualizar banco
            bulletin.script_text = script
            bulletin.metadata_json = {
                "started_at": datetime.utcnow().isoformat(),
                "news_used": [
                    {"title": n.title, "source": n.source, "score": n.relevance_score}
                    for n in top_news
                ],
            }
            self.db.commit()

            # === PASSO 4: Sintetizar voz ===
            logger.info(f"[{bulletin.id}] Gerando áudio com TTS...")
            audio_bytes = await self.tts.synthesize_with_music(script, period=period)
            duration = await self.tts.get_audio_duration(audio_bytes)
            logger.info(f"[{bulletin.id}] Áudio gerado ({duration:.0f}s, {len(audio_bytes)/1024/1024:.1f}MB)")

            # === PASSO 5: Upload para S3 ===
            logger.info(f"[{bulletin.id}] Fazendo upload...")
            audio_url = self.storage.upload_audio(
                audio_bytes,
                prefix="bulletins",
                filename=f"boletim_{period}_{bulletin.id}.mp3",
            )
            logger.info(f"[{bulletin.id}] Upload concluído: {audio_url}")

            # === PASSO 6: Atualizar banco ===
            bulletin.audio_url = audio_url
            bulletin.audio_duration = duration
            bulletin.transcript = script  # Usar roteiro como transcrição
            bulletin.status = BulletinStatus.READY

            if auto_publish:
                bulletin.status = BulletinStatus.PUBLISHED
                bulletin.published_at = datetime.utcnow()

            self.db.commit()
            self.db.refresh(bulletin)

            logger.info(f"[{bulletin.id}] Boletim {'publicado' if auto_publish else 'pronto'} com sucesso!")
            return bulletin

        except Exception as e:
            logger.error(f"[{bulletin.id}] Erro no pipeline: {e}", exc_info=True)
            bulletin.status = BulletinStatus.FAILED
            bulletin.metadata_json = {
                "error": str(e),
                "failed_at": datetime.utcnow().isoformat(),
            }
            self.db.commit()
            raise

    async def generate_all_daily(self):
        """Gera os 3 boletins do dia (manhã, tarde, noite)."""
        results = {}
        for period in ["manha", "tarde", "noite"]:
            try:
                results[period] = await self.generate_bulletin(period=period)
                logger.info(f"Boletim {period} gerado com sucesso")
            except Exception as e:
                logger.error(f"Erro ao gerar boletim {period}: {e}")
                results[period] = None
        return results

    async def retry_failed_bulletin(self, bulletin_id: int) -> Bulletin:
        """Reprocessa um boletim que falhou."""
        bulletin = self.db.query(Bulletin).filter(Bulletin.id == bulletin_id).first()
        if not bulletin:
            raise ValueError(f"Boletim {bulletin_id} não encontrado")

        if bulletin.status != BulletinStatus.FAILED:
            raise ValueError(f"Boletim {bulletin_id} não está em estado FAILED")

        # Deletar o registro antigo e recriar
        period = bulletin.period.value
        self.db.delete(bulletin)
        self.db.commit()

        return await self.generate_bulletin(period=period)
