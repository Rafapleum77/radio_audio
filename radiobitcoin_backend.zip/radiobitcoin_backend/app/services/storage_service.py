"""
Serviço de storage para upload/download de mídias (S3/R2).
Suporta AWS S3 e Cloudflare R2.
"""
import io
import logging
import uuid
from datetime import datetime
from typing import Optional

import boto3
from botocore.config import Config

from app.core.config import settings

logger = logging.getLogger(__name__)


class StorageService:
    """Upload e gerenciamento de arquivos de mídia em S3/R2."""

    def __init__(self):
        self.s3_client = boto3.client(
            "s3",
            endpoint_url=settings.s3_endpoint or None,
            aws_access_key_id=settings.s3_access_key,
            aws_secret_access_key=settings.s3_secret_key,
            region_name=settings.s3_region,
            config=Config(signature_version="s3v4"),
        )
        self.bucket = settings.s3_bucket
        self.cdn_url = settings.cdn_base_url.rstrip("/")

    def upload_audio(
        self,
        audio_bytes: bytes,
        content_type: str = "audio/mpeg",
        prefix: str = "bulletins",
        filename: Optional[str] = None,
    ) -> str:
        """
        Faz upload do áudio e retorna a URL pública.

        Args:
            audio_bytes: Bytes do arquivo MP3
            content_type: MIME type
            prefix: Pasta no bucket (bulletins, podcasts, ads)
            filename: Nome do arquivo (gera UUID se não fornecido)

        Returns:
            URL pública do arquivo
        """
        if not filename:
            ext = "mp3"
            filename = f"{uuid.uuid4().hex}.{ext}"

        date_str = datetime.utcnow().strftime("%Y/%m/%d")
        key = f"{prefix}/{date_str}/{filename}"

        try:
            self.s3_client.put_object(
                Bucket=self.bucket,
                Key=key,
                Body=audio_bytes,
                ContentType=content_type,
                CacheControl="public, max-age=31536000",  # 1 ano de cache
            )
            url = f"{self.cdn_url}/{key}"
            logger.info(f"Áudio uploadado: {url}")
            return url
        except Exception as e:
            logger.error(f"Erro ao uploadar áudio: {e}")
            raise

    def upload_image(
        self,
        image_bytes: bytes,
        content_type: str = "image/png",
        prefix: str = "thumbnails",
        filename: Optional[str] = None,
    ) -> str:
        """Upload de imagem (thumbnail, capa)."""
        if not filename:
            ext = "png" if "png" in content_type else "jpg"
            filename = f"{uuid.uuid4().hex}.{ext}"

        key = f"{prefix}/{filename}"

        try:
            self.s3_client.put_object(
                Bucket=self.bucket,
                Key=key,
                Body=image_bytes,
                ContentType=content_type,
                CacheControl="public, max-age=31536000",
            )
            return f"{self.cdn_url}/{key}"
        except Exception as e:
            logger.error(f"Erro ao uploadar imagem: {e}")
            raise

    def get_public_url(self, key: str) -> str:
        """Retorna URL pública para uma key existente."""
        return f"{self.cdn_url}/{key}"

    def delete_file(self, key: str) -> bool:
        """Deleta um arquivo do bucket."""
        try:
            self.s3_client.delete_object(Bucket=self.bucket, Key=key)
            return True
        except Exception as e:
            logger.error(f"Erro ao deletar {key}: {e}")
            return False
