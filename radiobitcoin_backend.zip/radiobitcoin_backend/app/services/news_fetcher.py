"""
Serviço de pesquisa de notícias cripto.
Combina múltiplas fontes (CryptoPanic, CoinGecko, Twitter/X) e ranqueia por relevância.
"""
import asyncio
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from dataclasses import dataclass

import httpx
from openai import OpenAI

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class NewsItem:
    title: str
    source: str
    url: str
    published_at: datetime
    sentiment: Optional[float] = None  # -1 a 1
    relevance_score: float = 0.0
    summary: Optional[str] = None


class NewsFetcher:
    """Busca e ranqueia notícias cripto de múltiplas fontes."""

    def __init__(self):
        self.openai = OpenAI(api_key=settings.openai_api_key) if settings.openai_api_key else None

    async def fetch_cryptopanic(self, top: int = 20) -> List[NewsItem]:
        """Busca notícias do CryptoPanic API."""
        if not settings.cryptopanic_api_key:
            logger.warning("CryptoPanic API key não configurada")
            return []

        url = "https://cryptopanic.com/api/free/v1/posts/"
        params = {
            "auth_token": settings.cryptopanic_api_key,
            "kind": "news",
            "public": "true",
            "filter": "hot",
            "currencies": "BTC",
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(url, params=params)
                response.raise_for_status()
                data = response.json()

                items = []
                for post in data.get("results", [])[:top]:
                    items.append(NewsItem(
                        title=post.get("title", ""),
                        source="CryptoPanic",
                        url=post.get("url", ""),
                        published_at=datetime.fromisoformat(
                            post.get("published_at", "").replace("Z", "+00:00")
                        ),
                        sentiment=post.get("sentiment"),
                    ))
                return items
        except Exception as e:
            logger.error(f"Erro ao buscar CryptoPanic: {e}")
            return []

    async def fetch_coingecko(self) -> List[NewsItem]:
        """Busca trending coins e mudanças de preço do CoinGecko."""
        if not settings.coingecko_api_key:
            return []

        items = []
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                # Trending
                response = await client.get(
                    "https://api.coingecko.com/api/v3/search/trending"
                )
                data = response.json()
                for coin in data.get("coins", [])[:10]:
                    item = coin.get("item", {})
                    items.append(NewsItem(
                        title=f"Trending: {item.get('name')} ({item.get('symbol', '')})",
                        source="CoinGecko",
                        url=f"https://www.coingecko.com/en/coins/{item.get('id', '')}",
                        published_at=datetime.utcnow(),
                    ))

                # Bitcoin price
                response = await client.get(
                    "https://api.coingecko.com/api/v3/simple/price",
                    params={"ids": "bitcoin,ethereum", "vs_currencies": "usd,brl", "include_24hr_change": "true"}
                )
                prices = response.json()
                btc = prices.get("bitcoin", {})
                if btc:
                    change = btc.get("usd_24h_change", 0)
                    direction = "subiu" if change >= 0 else "caiu"
                    items.append(NewsItem(
                        title=f"Bitcoin está em ${btc.get('usd', 0):,.0f} ({direction} {abs(change):.1f}% nas 24h)",
                        source="CoinGecko",
                        url="https://www.coingecko.com/en/coins/bitcoin",
                        published_at=datetime.utcnow(),
                    ))
        except Exception as e:
            logger.error(f"Erro ao buscar CoinGecko: {e}")

        return items

    async def fetch_twitter(self, query: str = "bitcoin", top: int = 10) -> List[NewsItem]:
        """Busca tweets relevantes sobre Bitcoin (requer API do X)."""
        # Implementação simplificada - requer bearer token do X/Twitter API v2
        if not hasattr(settings, "twitter_bearer_token") or not getattr(settings, "twitter_bearer_token", ""):
            return []

        items = []
        try:
            url = "https://api.twitter.com/2/tweets/search/recent"
            headers = {"Authorization": f"Bearer {settings.twitter_bearer_token}"}
            params = {"query": query, "max_results": top, "tweet.fields": "created_at,public_metrics"}

            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(url, headers=headers, params=params)
                if response.status_code == 200:
                    data = response.json()
                    for tweet in data.get("data", []):
                        metrics = tweet.get("public_metrics", {})
                        items.append(NewsItem(
                            title=tweet.get("text", "")[:200],
                            source="Twitter",
                            url=f"https://twitter.com/i/status/{tweet.get('id')}",
                            published_at=datetime.fromisoformat(
                                tweet.get("created_at", "").replace("Z", "+00:00")
                            ),
                        ))
        except Exception as e:
            logger.error(f"Erro ao buscar Twitter: {e}")

        return items

    async def fetch_all(self, top_per_source: int = 20) -> List[NewsItem]:
        """Busca de todas as fontes em paralelo."""
        results = await asyncio.gather(
            self.fetch_cryptopanic(top_per_source),
            self.fetch_coingecko(),
            self.fetch_twitter(),
            return_exceptions=True,
        )

        all_items = []
        for result in results:
            if isinstance(result, list):
                all_items.extend(result)

        return all_items

    async def rank_by_relevance(
        self,
        items: List[NewsItem],
        period: str = "manha",
        top_n: int = 5,
    ) -> List[NewsItem]:
        """
        Usa IA para ranquear as notícias por relevância para o boletim.
        Considera: impacto no mercado, novidade, relevância para o público.
        """
        if not self.openai or not items:
            # Fallback: ordenar por data (mais recente primeiro)
            return sorted(items, key=lambda x: x.published_at, reverse=True)[:top_n]

        # Preparar contexto do período
        period_context = {
            "manha": "Boletim da manhã - informativo e energético, foco em notícias quentes e mercado ao abrir",
            "tarde": "Boletim da tarde - analítico e profundo, foco em tendências e análises",
            "noite": "Boletim da noite - resumo relaxado, balanço do dia e perspectivas",
        }

        # Criar lista de notícias para o LLM avaliar
        news_list = "\n".join([
            f"{i}. [{item.source}] {item.title} ({item.published_at.strftime('%H:%M')})"
            for i, item in enumerate(items, 1)
        ])

        prompt = f"""
Você é um editor de notícias cripto experiente. Avalie as seguintes notícias para um boletim de rádio:

Contexto: {period_context.get(period, "")}

Notícias disponíveis:
{news_list}

Para cada notícia, atribua um score de relevância de 0 a 100 considerando:
- Impacto no mercado Bitcoin/cripto
- Novidade (quanto mais recente, mais relevante)
- Relevância para o público da Rádio Bitcoin
- Potencial de engajamento dos ouvintes

Responda APENAS com um JSON array de objetos: {{"index": <numero>, "score": <0-100>}}
"""

        try:
            response = self.openai.chat.completions.create(
                model=settings.openai_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=2000,
            )

            scores = eval(response.choices[0].message.content)
            for score_item in scores:
                idx = score_item.get("index", 0) - 1
                score = score_item.get("score", 0)
                if 0 <= idx < len(items):
                    items[idx].relevance_score = score / 100.0

            # Ordenar por score e retornar top N
            items.sort(key=lambda x: x.relevance_score, reverse=True)
            return items[:top_n]

        except Exception as e:
            logger.error(f"Erro ao ranquear notícias com IA: {e}")
            # Fallback
            return sorted(items, key=lambda x: x.published_at, reverse=True)[:top_n]
