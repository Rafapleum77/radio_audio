"""
Configurações centralizadas da aplicação.
Lê variáveis de ambiente com pydantic-settings.
"""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # App
    app_name: str = "Rádio Bitcoin API"
    app_version: str = "1.0.0"
    debug: bool = False
    api_prefix: str = "/api/v1"
    cors_origins: str = "http://localhost:3000,https://radiobitcoin.org"

    # Database
    database_url: str = "postgresql://radiobitcoin:secret@localhost:5432/radiobitcoin"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # JWT Auth
    secret_key: str = "change-me-to-a-secret-key-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60 * 24 * 7  # 7 dias

    # OpenAI (geração de texto)
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"

    # ElevenLabs (TTS)
    elevenlabs_api_key: str = ""
    elevenlabs_voice_id: str = "21m00Tcm4TlvDq8ikWAM"  # Voz padrão
    elevenlabs_model: str = "eleven_multilingual_v2"

    # Crypto News APIs
    cryptopanic_api_key: str = ""
    coingecko_api_key: str = ""

    # S3 Storage (Cloudflare R2 ou AWS S3)
    s3_bucket: str = "radiobitcoin-media"
    s3_endpoint: str = ""
    s3_access_key: str = ""
    s3_secret_key: str = ""
    s3_region: str = "auto"
    cdn_base_url: str = "https://media.radiobitcoin.org"

    # Stripe
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""

    # Streaming
    hls_base_url: str = "https://live.radiobitcoin.org/hls"
    rtmp_url: str = "rtmp://localhost:1935/live"

    # Scheduler
    bulletin_schedule_manha: str = "06:00"
    bulletin_schedule_tarde: str = "12:00"
    bulletin_schedule_noite: str = "20:00"

    # FFmpeg
    ffmpeg_intro_path: str = "/app/assets/intro.mp3"
    ffmpeg_outro_path: str = "/app/assets/outro.mp3"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
