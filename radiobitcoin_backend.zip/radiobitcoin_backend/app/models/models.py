"""
Modelos de banco de dados para a Rádio Bitcoin.
Usa SQLAlchemy com PostgreSQL.
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Boolean, Float, DateTime, ForeignKey, JSON, Enum as SQLEnum
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
import enum

Base = declarative_base()


class BulletinPeriod(enum.Enum):
    MANHA = "manha"
    TARDE = "tarde"
    NOITE = "noite"


class BulletinStatus(enum.Enum):
    DRAFT = "draft"
    GENERATING = "generating"
    READY = "ready"
    PUBLISHED = "published"
    FAILED = "failed"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=True)
    role = Column(String(50), default="user")  # user, admin, subscriber
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    subscription = relationship("Subscription", back_populates="user", uselist=False)
    events = relationship("AnalyticsEvent", back_populates="user")


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    plan = Column(String(50), nullable=False)  # free, basico, pro
    stripe_customer_id = Column(String(255), nullable=True)
    stripe_subscription_id = Column(String(255), nullable=True)
    status = Column(String(50), default="active")  # active, canceled, past_due
    current_period_start = Column(DateTime, nullable=True)
    current_period_end = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="subscription")


class Bulletin(Base):
    __tablename__ = "bulletins"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(500), nullable=False)
    period = Column(SQLEnum(BulletinPeriod), nullable=False)
    status = Column(SQLEnum(BulletinStatus), default=BulletinStatus.DRAFT)
    script_text = Column(Text, nullable=True)  # Roteiro gerado pela IA
    transcript = Column(Text, nullable=True)   # Transcrição do áudio
    audio_url = Column(String(1000), nullable=True)
    audio_duration = Column(Float, nullable=True)  # em segundos
    thumbnail_url = Column(String(1000), nullable=True)
    metadata_json = Column(JSON, nullable=True)  # Notícias usadas, scores, etc.
    play_count = Column(Integer, default=0)
    share_count = Column(Integer, default=0)
    sponsor_slots = Column(JSON, nullable=True)  # {"preroll": "...", "midroll": "..."}
    created_at = Column(DateTime, default=datetime.utcnow)
    published_at = Column(DateTime, nullable=True)

    comments = relationship("Comment", back_populates="bulletin")


class Podcast(Base):
    __tablename__ = "podcasts"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=True)
    cover_url = Column(String(1000), nullable=True)
    is_active = Column(Boolean, default=True)
    total_episodes = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    episodes = relationship("PodcastEpisode", back_populates="podcast")


class PodcastEpisode(Base):
    __tablename__ = "podcast_episodes"

    id = Column(Integer, primary_key=True, index=True)
    podcast_id = Column(Integer, ForeignKey("podcasts.id"), nullable=False)
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=True)
    audio_url = Column(String(1000), nullable=True)
    audio_duration = Column(Float, nullable=True)
    transcript = Column(Text, nullable=True)
    thumbnail_url = Column(String(1000), nullable=True)
    play_count = Column(Integer, default=0)
    published_at = Column(DateTime, default=datetime.utcnow)

    podcast = relationship("Podcast", back_populates="episodes")


class Comment(Base):
    __tablename__ = "comments"

    id = Column(Integer, primary_key=True, index=True)
    bulletin_id = Column(Integer, ForeignKey("bulletins.id"), nullable=True)
    podcast_episode_id = Column(Integer, ForeignKey("podcast_episodes.id"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    text = Column(Text, nullable=False)
    is_approved = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    bulletin = relationship("Bulletin", back_populates="comments")
    user = relationship("User")


class AnalyticsEvent(Base):
    __tablename__ = "analytics_events"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    event_type = Column(String(100), nullable=False)  # play, share, subscribe, page_view
    content_type = Column(String(50), nullable=True)  # bulletin, podcast
    content_id = Column(Integer, nullable=True)
    metadata_json = Column(JSON, nullable=True)
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    user = relationship("User", back_populates="events")


class AffiliateLink(Base):
    __tablename__ = "affiliate_links"

    id = Column(Integer, primary_key=True, index=True)
    partner = Column(String(100), nullable=False)  # binance, bybit, ledger, trezor
    url = Column(String(1000), nullable=False)
    commission_rate = Column(Float, default=0.0)  # 0.30 = 30%
    click_count = Column(Integer, default=0)
    conversion_count = Column(Integer, default=0)
    revenue_total = Column(Float, default=0.0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Sponsor(Base):
    __tablename__ = "sponsors"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    ad_audio_url = Column(String(1000), nullable=True)
    cpm_rate = Column(Float, default=0.0)
    total_impressions = Column(Integer, default=0)
    total_spend = Column(Float, default=0.0)
    start_date = Column(DateTime, nullable=True)
    end_date = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
