# Rádio Bitcoin — Backend API

Backend completo da Rádio Bitcoin com geração automática de boletins diários via IA.

## Arquitetura

```
┌─────────────────────────────────────────────────────────────┐
│                    RÁDIO BITCOIN BACKEND                     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────┐    ┌──────────┐    ┌───────────────────────┐ │
│  │ FastAPI  │    │ APSched. │    │    Pipeline de IA      │ │
│  │  (API)   │    │(Scheduler)│   │                       │ │
│  └────┬─────┘    └────┬─────┘    │ 1. News Fetcher       │ │
│       │               │          │    (CryptoPanic, CG, X)│ │
│  ┌────┴───────────────┴──────┐   │ 2. IA Ranking          │ │
│  │      PostgreSQL           │   │    (GPT-4 relevance)   │ │
│  └───────────────────────────┘   │ 3. Script Generator    │ │
│       │                          │    (GPT-4 roteiro)     │ │
│  ┌────┴──────┐                   │ 4. TTS (ElevenLabs)   │ │
│  │   Redis   │                   │ 5. Mix (intro/outro)  │ │
│  └───────────┘                   │ 6. S3 Upload (R2)     │ │
│                                  └───────────────────────┘ │
│  ┌──────────────┐    ┌──────────────┐                      │
│  │   Stripe     │    │   ElevenLabs │                      │
│  │ (Payments)   │    │   (TTS)      │                      │
│  └──────────────┘    └──────────────┘                      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

### Com Docker (recomendado)

```bash
# 1. Copiar .env.example para .env e configurar
cp .env.example .env
# Editar .env com suas API keys

# 2. Build e start
docker compose up -d --build

# 3. Ver logs
docker compose logs -f api
docker compose logs -f scheduler
```

### Sem Docker (desenvolvimento)

```bash
# 1. Criar virtualenv
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2. Instalar dependências
pip install -r requirements.txt

# 3. Configurar .env
cp .env.example .env
# Editar com suas keys

# 4. Instalar PostgreSQL e Redis localmente, ou usar Docker só para eles:
docker compose up -d postgres redis

# 5. Rodar a API
uvicorn main:app --reload --port 8000

# 6. Rodar o scheduler (em outro terminal)
python scripts/scheduler.py
```

## Endpoints Principais

### Auth
| Método | Endpoint | Descrição |
|---|---|---|
| POST | `/api/v1/auth/register` | Registrar usuário |
| POST | `/api/v1/auth/login` | Login (retorna JWT) |
| GET | `/api/v1/auth/me` | Perfil do usuário logado |

### Boletins
| Método | Endpoint | Descrição |
|---|---|---|
| GET | `/api/v1/bulletins/` | Listar boletins (paginado) |
| GET | `/api/v1/bulletins/latest` | Último boletim |
| GET | `/api/v1/bulletins/{id}` | Detalhes de um boletim |
| POST | `/api/v1/bulletins/generate` | Gerar boletim com IA |
| POST | `/api/v1/bulletins/generate-all` | Gerar 3 boletins do dia |
| POST | `/api/v1/bulletins/{id}/play` | Registrar play |
| POST | `/api/v1/bulletins/{id}/share` | Registrar share |

### Podcasts
| Método | Endpoint | Descrição |
|---|---|---|
| GET | `/api/v1/podcasts/` | Listar podcasts |
| GET | `/api/v1/podcasts/{id}/episodes` | Episódios de um podcast |
| POST | `/api/v1/podcasts/episodes/{id}/play` | Registrar play |

### Assinaturas (Stripe)
| Método | Endpoint | Descrição |
|---|---|---|
| GET | `/api/v1/subscriptions/me` | Minha assinatura |
| POST | `/api/v1/subscriptions/create-checkout` | Criar checkout |
| POST | `/api/v1/subscriptions/webhook` | Webhook Stripe |
| POST | `/api/v1/subscriptions/cancel` | Cancelar assinatura |

### Analytics
| Método | Endpoint | Descrição |
|---|---|---|
| GET | `/api/v1/analytics/summary` | Resumo geral |
| GET | `/api/v1/analytics/events` | Eventos brutos |
| GET | `/api/v1/analytics/revenue` | Receita (afiliados + sponsors) |
| GET | `/api/v1/analytics/plays-by-day` | Plays por dia |

### Admin
| Método | Endpoint | Descrição |
|---|---|---|
| GET | `/api/v1/admin/stats` | Dashboard admin |
| POST | `/api/v1/admin/generate-all` | Gerar boletins (admin) |
| POST | `/api/v1/admin/retry/{id}` | Reprocessar boletim falho |
| GET | `/api/v1/admin/users` | Listar usuários |
| GET | `/api/v1/admin/affiliates` | Links de afiliados |
| GET | `/api/v1/admin/sponsors` | Patrocinadores |

## Pipeline de IA — Como funciona

```
┌─────────┐     ┌─────────┐     ┌─────────┐     ┌─────────┐     ┌─────────┐
│ Notícias │ ──→ │ Ranking │ ──→ │ Roteiro │ ──→ │  TTS    │ ──→ │ Upload  │
│ (IA)    │     │ (IA)    │     │ (GPT-4) │     │(ElevenL)│     │  (S3)   │
└─────────┘     └─────────┘     └─────────┘     └─────────┘     └─────────┘
     │               │               │               │               │
  CryptoPanic    Score 0-100    ~600 palavras    ~3min áudio      CDN URL
  CoinGecko      por relevância  por boletim     mixado c/ intro
  Twitter/X      com GPT-4      tom por período  e outro
```

1. **News Fetcher**: Busca notícias de CryptoPanic, CoinGecko e Twitter em paralelo
2. **IA Ranking**: GPT-4 avalia cada notícia (impacto, novidade, relevância) e atribui score 0-100
3. **Script Generator**: GPT-4 escreve roteiro de ~600 palavras com tom adequado ao período
4. **TTS**: ElevenLabs converte o texto em áudio profissional (~3 min)
5. **Mixagem**: Adiciona intro e outro com crossfade
6. **Upload**: S3/R2 com CDN para entrega rápida

## Scheduler Automático

O scheduler gera automaticamente 3 boletins por dia:
- **Manhã** (06:00): Tom energético, notícias quentes
- **Tarde** (12:00): Tom analítico, tendências e profundidade
- **Noite** (20:00): Tom relaxado, balanço do dia

## Requisitos de API Keys

| Serviço | Para quê | Obrigatório |
|---|---|---|
| OpenAI | Gerar roteiros e rankar notícias | Sim |
| ElevenLabs | Text-to-Speech | Sim |
| CryptoPanic | Buscar notícias cripto | Recomendado |
| CoinGecko | Preços e trending | Opcional (grátis) |
| Twitter/X | Tweets sobre Bitcoin | Opcional |
| Stripe | Assinaturas e pagamentos | Somente para monetização |
| Cloudflare R2 / AWS S3 | Storage de áudio | Sim |
