"""
Scheduler de boletins automáticos.
Agenda a geração dos 3 boletins diários (manhã, tarde, noite)
usando APScheduler.

Uso:
    python scripts/scheduler.py

Ou via Docker:
    docker compose exec backend python scripts/scheduler.py
"""
import asyncio
import logging
from datetime import datetime

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.config import settings
from app.services.bulletin_pipeline import BulletinPipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("scheduler")


def run_pipeline(period: str):
    """Executa o pipeline de geração de boletim para um período."""
    logger.info(f"⏰ Iniciando geração do boletim {period} - {datetime.now()}")

    engine = create_engine(settings.database_url)
    Session = sessionmaker(bind=engine)
    db = Session()

    try:
        pipeline = BulletinPipeline(db)
        asyncio.run(pipeline.generate_bulletin(period=period, auto_publish=True))
        logger.info(f"✅ Boletim {period} gerado com sucesso")
    except Exception as e:
        logger.error(f"❌ Erro ao gerar boletim {period}: {e}", exc_info=True)
    finally:
        db.close()


def run_all_daily():
    """Gera os 3 boletins do dia."""
    logger.info("📻 Iniciando geração dos 3 boletins diários...")
    for period in ["manha", "tarde", "noite"]:
        run_pipeline(period)


def main():
    """Configura e inicia o scheduler."""
    logger.info("🎙️  Rádio Bitcoin Scheduler - Iniciando")
    logger.info(f"   Boletim Manhã: {settings.bulletin_schedule_manha}")
    logger.info(f"   Boletim Tarde: {settings.bulletin_schedule_tarde}")
    logger.info(f"   Boletim Noite: {settings.bulletin_schedule_noite}")

    scheduler = AsyncIOScheduler()

    # Agendar boletim da manhã
    scheduler.add_job(
        lambda: run_pipeline("manha"),
        "cron",
        hour=int(settings.bulletin_schedule_manha.split(":")[0]),
        minute=int(settings.bulletin_schedule_manha.split(":")[1]),
        id="bulletin_manha",
        name="Boletim Manhã",
    )

    # Agendar boletim da tarde
    scheduler.add_job(
        lambda: run_pipeline("tarde"),
        "cron",
        hour=int(settings.bulletin_schedule_tarde.split(":")[0]),
        minute=int(settings.bulletin_schedule_tarde.split(":")[1]),
        id="bulletin_tarde",
        name="Boletim Tarde",
    )

    # Agendar boletim da noite
    scheduler.add_job(
        lambda: run_pipeline("noite"),
        "cron",
        hour=int(settings.bulletin_schedule_noite.split(":")[0]),
        minute=int(settings.bulletin_schedule_noite.split(":")[1]),
        id="bulletin_noite",
        name="Boletim Noite",
    )

    # Gerar imediatamente ao iniciar (útil para testes)
    # Descomente a linha abaixo para gerar ao start:
    # run_all_daily()

    scheduler.start()
    logger.info("⏰ Scheduler ativo. Aguardando horários dos boletins...")

    try:
        asyncio.get_event_loop().run_forever()
    except KeyboardInterrupt:
        logger.info("👋 Scheduler encerrado")


if __name__ == "__main__":
    main()
