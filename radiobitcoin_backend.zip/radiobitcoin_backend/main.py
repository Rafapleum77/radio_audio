"""
Rádio Bitcoin - Backend API
FastAPI application principal.
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.models.database import init_db
from app.api.v1.router import api_v1_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle: inicializa o banco de dados na startup."""
    print("🎙️  Rádio Bitcoin API - Iniciando...")
    init_db()
    print("📊 Banco de dados inicializado")
    yield
    print("👋 Rádio Bitcoin API - Encerrando...")


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Backend da Rádio Bitcoin - Boletins diários com IA, podcasts, assinaturas e analytics",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS
origins = [origin.strip() for origin in settings.cors_origins.split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API v1
app.include_router(api_v1_router, prefix=settings.api_prefix)


@app.get("/health")
def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "version": settings.app_version,
        "name": settings.app_name,
    }


@app.get("/")
def root():
    """Root endpoint."""
    return {
        "message": "Rádio Bitcoin API",
        "docs": "/docs",
        "health": "/health",
        "api": settings.api_prefix,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
    )
