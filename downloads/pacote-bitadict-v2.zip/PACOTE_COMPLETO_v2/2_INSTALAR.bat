@echo off
REM ===========================================================================
REM BIT ADICT - SETUP v3 (bulletproof - incorpora todo aprendizado de 21/mai/2026)
REM ===========================================================================
chcp 65001 >nul 2>&1
title BIT ADICT - SETUP v3

set "INSTALL_DIR=C:\BIT_ADICT"
set "LOG=%INSTALL_DIR%\setup.log"

REM === 0. Cria pasta base + log ===
mkdir "%INSTALL_DIR%" 2>nul
mkdir "%INSTALL_DIR%\SCAN" 2>nul
mkdir "%INSTALL_DIR%\SCAN\imagens" 2>nul
mkdir "%INSTALL_DIR%\SCAN\textos_suspeitos" 2>nul
mkdir "%INSTALL_DIR%\SCAN\wallets" 2>nul
mkdir "%INSTALL_DIR%\logs" 2>nul
cd /d "%INSTALL_DIR%"
echo. > "%LOG%"
echo BIT ADICT SETUP v3 - %DATE% %TIME% > "%LOG%"

cls
echo.
echo ================================================================
echo   BIT ADICT - INSTALADOR v3
echo   Versao bulletproof - 21/mai/2026
echo ================================================================
echo.
echo Tempo estimado: 12-15 minutos
echo Log completo em: %LOG%
echo.

REM === 1. Verifica admin ===
net session >nul 2>&1
if errorlevel 1 (
  echo [X] Esse arquivo precisa ser rodado como ADMINISTRADOR.
  echo.
  echo Fecha essa janela, clica com BOTAO DIREITO no .bat
  echo e escolhe "Executar como administrador".
  echo.
  pause
  exit /b 1
)
echo [OK] Rodando como Administrador.
echo.

REM === 2. Verifica Windows 10/11 ===
echo [1/8] Verificando versao do Windows...
echo [1/8] Win check >> "%LOG%"
ver | findstr /i "10.0" >nul
if errorlevel 1 (
  echo [X] Esse instalador requer Windows 10 ou 11.
  echo Sistema detectado:
  ver
  echo Atualiza o Windows antes de continuar.
  pause
  exit /b 1
)
echo [OK] Windows 10/11 detectado.
echo.

REM === 3. Configura DNS Cloudflare (resolve bloqueio de polymarket.com) ===
echo [2/8] Configurando DNS Cloudflare 1.1.1.1 (anti-bloqueio ISP)...
echo [2/8] DNS >> "%LOG%"
powershell -NoProfile -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ('1.1.1.1','1.0.0.1') -ErrorAction SilentlyContinue }" >> "%LOG%" 2>&1
REM Desabilita IPv6 nos adaptadores conectados (importante - roteadores bloqueiam via IPv6)
powershell -NoProfile -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { Disable-NetAdapterBinding -Name $_.Name -ComponentID ms_tcpip6 -ErrorAction SilentlyContinue }" >> "%LOG%" 2>&1
ipconfig /flushdns >nul 2>&1
echo [OK] DNS Cloudflare + IPv6 desabilitado.
echo.

REM === 4. Testa se DNS resolve clob.polymarket.com ===
echo [3/8] Testando conectividade Polymarket...
echo [3/8] Conectividade >> "%LOG%"
nslookup clob.polymarket.com 1.1.1.1 >> "%LOG%" 2>&1
ping -n 2 clob.polymarket.com >nul 2>&1
if errorlevel 1 (
  echo [!] AVISO: clob.polymarket.com nao resolve mesmo com Cloudflare.
  echo [!] ISP/roteador esta bloqueando por IP. Solucoes:
  echo     1. Usa 4G do celular como hotspot
  echo     2. Instala Cloudflare WARP: https://1.1.1.1/
  echo     3. Usa NordVPN
  echo.
  echo Pressiona ENTER pra continuar mesmo assim ^(bot vai dar erro de DNS depois^)
  pause >nul
) else (
  echo [OK] Polymarket acessivel.
)
echo.

REM === 5. Python 3.11 ===
echo [4/8] Verificando Python 3.11...
echo [4/8] Python >> "%LOG%"

REM Primeiro testa se py -3.11 funciona (launcher Windows)
py -3.11 --version >nul 2>&1
if not errorlevel 1 (
  py -3.11 --version
  echo [OK] Python 3.11 ja instalado via py launcher.
  set "PY=py -3.11"
  goto :py_pronto
)

REM Senao, tenta winget (Windows 10 1809+)
echo Python 3.11 nao encontrado. Tentando instalar via winget...
where winget >nul 2>&1
if not errorlevel 1 (
  winget install --silent --accept-source-agreements --accept-package-agreements Python.Python.3.11 >> "%LOG%" 2>&1
  set "PATH=%PATH%;%LOCALAPPDATA%\Programs\Python\Python311;%LOCALAPPDATA%\Programs\Python\Python311\Scripts"
  py -3.11 --version >nul 2>&1
  if not errorlevel 1 (
    py -3.11 --version
    echo [OK] Python 3.11 instalado via winget.
    set "PY=py -3.11"
    goto :py_pronto
  )
)

REM Fallback: download direto python.org
echo Tentando download direto do python.org...
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\py311.exe' -UseBasicParsing" >> "%LOG%" 2>&1
if not exist "%TEMP%\py311.exe" (
  echo [X] Falha no download do Python. Verifica conexao.
  pause & exit /b 1
)
start /wait "" "%TEMP%\py311.exe" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0 Include_pip=1 Include_launcher=1
set "PATH=%PATH%;C:\Program Files\Python311;C:\Program Files\Python311\Scripts"
py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo [X] Python nao foi instalado corretamente.
  echo Tenta rodar manualmente: %TEMP%\py311.exe
  pause & exit /b 1
)
set "PY=py -3.11"

:py_pronto
echo.

REM === 6. Bibliotecas Python ===
echo [5/8] Instalando bibliotecas Python ^(4-6 min^)...
echo [5/8] Libs >> "%LOG%"
%PY% -m pip install --upgrade pip --quiet >> "%LOG%" 2>&1
%PY% -m pip install --quiet bip-utils web3 python-dotenv requests pandas numpy pillow ccxt >> "%LOG%" 2>&1
echo Instalando py_clob_client_v2 ^(Polymarket SDK^)...
%PY% -m pip install --quiet py_clob_client_v2 >> "%LOG%" 2>&1
if errorlevel 1 (
  echo Fallback: instalando direto do GitHub...
  %PY% -m pip install --quiet git+https://github.com/Polymarket/py-clob-client-v2.git >> "%LOG%" 2>&1
)
echo [OK] Bibliotecas instaladas.
echo.

REM === 7. Baixa arquivos BIT ADICT ===
echo [6/8] Baixando Recovery Kit + Bot DIRECIONAL v2.1 + Scanner...
echo [6/8] Downloads >> "%LOG%"
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://radiobitcoin.org/scripts/recovery_kit.py' -OutFile '%INSTALL_DIR%\recovery_kit.py' -UseBasicParsing" >> "%LOG%" 2>&1
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://radiobitcoin.org/scripts/bip39_en.txt' -OutFile '%INSTALL_DIR%\bip39_en.txt' -UseBasicParsing" >> "%LOG%" 2>&1
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://radiobitcoin.org/scripts/scan_seeds_imagens.ps1' -OutFile '%INSTALL_DIR%\scan_seeds_imagens.ps1' -UseBasicParsing" >> "%LOG%" 2>&1
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://radiobitcoin.org/scripts/bot_direcional_v2.py' -OutFile '%INSTALL_DIR%\bot_direcional_v2.py' -UseBasicParsing" >> "%LOG%" 2>&1
echo Arquivos baixados em %INSTALL_DIR%: >> "%LOG%"
dir /b "%INSTALL_DIR%\*.py" "%INSTALL_DIR%\*.txt" "%INSTALL_DIR%\*.ps1" >> "%LOG%" 2>&1
echo [OK] Arquivos baixados.
echo.

REM === 8. Cria template .env (cliente preenche depois) ===
echo [7/8] Criando template .env...
echo [7/8] .env template >> "%LOG%"
(
  echo # BIT ADICT bot DIRECIONAL v2 - config wallet
  echo # IMPORTANTE: preenche este arquivo seguindo o guia em:
  echo # https://radiobitcoin.org/wallet-setup.html
  echo.
  echo # ===== POLYMARKET WALLET ^(Deposit Wallet via email^) =====
  echo POLY_KEY=PREENCHA_AQUI_a_private_key_de_Settings_Export_Private_Key
  echo POLY_FUNDER=PREENCHA_AQUI_o_endereco_proxyWallet_em_Settings
  echo.
  echo # ===== RELAYER API ^(criada em Settings ^> Chaves API do Relayer^) =====
  echo RELAYER_API_KEY=PREENCHA_AQUI_a_chave_uuid
  echo RELAYER_API_KEY_ADDRESS=PREENCHA_AQUI_o_endereco_assinante
  echo.
  echo # ===== BANCA E ESTRATEGIA =====
  echo VALOR_TRADE=2.0
  echo STOP_LOSS=40.0
  echo CONFIANCA_MIN=70
  echo PRECO_MIN=0.45
  echo.
  echo # ===== MODO =====
  echo DRY_RUN=false
  echo SKIP_BALANCE_CHECK=true
  echo SIGNATURE_TYPE=POLY_1271
  echo.
  echo # ===== INFRA =====
  echo POLY_RPC=https://polygon-bor-rpc.publicnode.com
  echo LOG_PATH=C:\BIT_ADICT\logs\direcional.log
  echo TELEGRAM_TOKEN=
  echo TELEGRAM_CHAT_ID=
) > "%INSTALL_DIR%\.env.template"
echo [OK] Template em %INSTALL_DIR%\.env.template
echo.

REM === 9. Scanner de imagens/seeds ===
echo [8/8] Executando Scanner ^(opcional, 3-5 min^)...
echo Vou procurar imagens, textos com palavras BIP39 e wallets ja instaladas.
echo Tudo fica em C:\BIT_ADICT\SCAN. Util pra backup antes de configurar Recovery Kit.
echo.
choice /C SN /T 30 /D N /M "Rodar scanner agora? [S/N] (default N em 30s)"
if errorlevel 2 (
  echo Scanner pulado. Tu pode rodar depois clicando no atalho SCAN.
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%INSTALL_DIR%\scan_seeds_imagens.ps1"
)
echo.

REM === 10. Atalhos no Desktop ===
echo Criando atalhos na area de trabalho...
echo Atalhos >> "%LOG%"
for /f "delims=" %%i in ('where py') do set PYEXE=%%i

powershell -NoProfile -Command "$s = New-Object -ComObject WScript.Shell; $sc = $s.CreateShortcut('%PUBLIC%\Desktop\BOT BIT ADICT.lnk'); $sc.TargetPath = 'cmd.exe'; $sc.Arguments = '/k cd /d C:\BIT_ADICT && py -3.11 bot_direcional_v2.py'; $sc.WorkingDirectory = 'C:\BIT_ADICT'; $sc.Save()" >> "%LOG%" 2>&1
powershell -NoProfile -Command "$s = New-Object -ComObject WScript.Shell; $sc = $s.CreateShortcut('%PUBLIC%\Desktop\RECOVERY KIT.lnk'); $sc.TargetPath = 'cmd.exe'; $sc.Arguments = '/k cd /d C:\BIT_ADICT && py -3.11 recovery_kit.py'; $sc.WorkingDirectory = 'C:\BIT_ADICT'; $sc.Save()" >> "%LOG%" 2>&1
powershell -NoProfile -Command "$s = New-Object -ComObject WScript.Shell; $sc = $s.CreateShortcut('%PUBLIC%\Desktop\CONFIGURAR WALLET.lnk'); $sc.TargetPath = 'https://radiobitcoin.org/wallet-setup.html'; $sc.Save()" >> "%LOG%" 2>&1
powershell -NoProfile -Command "$s = New-Object -ComObject WScript.Shell; $sc = $s.CreateShortcut('%PUBLIC%\Desktop\PASTA BIT ADICT.lnk'); $sc.TargetPath = 'C:\BIT_ADICT'; $sc.Save()" >> "%LOG%" 2>&1
echo [OK] Atalhos criados.

echo.
echo ================================================================
echo   SETUP COMPLETO!
echo ================================================================
echo.
echo  PROXIMOS PASSOS:
echo.
echo  1. Abre o atalho "CONFIGURAR WALLET" no Desktop
echo     Vai abrir o guia visual em radiobitcoin.org/wallet-setup.html
echo     Segue cada tela do guia ^(10-15 min^)
echo.
echo  2. Quando terminar, abre o atalho "BOT BIT ADICT" no Desktop
echo     Bot vai iniciar e operar 24/7 sozinho
echo.
echo  3. Pra ver tudo organizado, abre "PASTA BIT ADICT" no Desktop
echo.
echo  Log completo dessa instalacao: %LOG%
echo.
echo  Suporte: WhatsApp +55 61 99811-0979
echo.
pause
