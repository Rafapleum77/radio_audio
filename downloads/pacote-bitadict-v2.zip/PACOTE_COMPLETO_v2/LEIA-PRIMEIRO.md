# 🛡️ PACOTE COMPLETO BIT ADICT v2 — €149 / $149

> **Atualizado em 2026-05-21** — incorpora todo aprendizado real do primeiro deploy live.

**Conteúdo deste pen drive:**

```
PACOTE_COMPLETO_v2/
├── 0_LEIA-PRIMEIRO.md      ← este arquivo (5 min de leitura)
├── 1_PRE_REQUISITOS.md     ← confere ANTES de instalar (3 min)
├── 2_INSTALAR.bat          ← clique 2x como Administrador (15 min)
├── 3_MANUAL_v3.md          ← passo a passo se travar (20 min)
├── 4_TROUBLESHOOTING.md    ← problemas comuns + solução (consulta)
├── RECOVERY_KIT/           ← utilitário offline pra recuperar wallets
└── BOTS/                   ← 4 bots Polymarket pré-configurados
```

## 🎯 Visão geral · 3 etapas

### Etapa 1: Sistema (15 min) — automático
Clica em **`2_INSTALAR.bat`** com botão direito → **Executar como administrador**.
Script faz tudo sozinho: Python 3.11, libs, DNS Cloudflare, Recovery Kit, atalhos no Desktop.

### Etapa 2: Polymarket (10 min) — humano
Tu cria conta na Polymarket (email novo só pra trading), deposita USDC, gera Relayer API Key.
**Guia visual completo em [radiobitcoin.org/wallet-setup.html](https://radiobitcoin.org/wallet-setup.html)** (abre no Chrome com cada tela explicada com print).

### Etapa 3: Conectar bot (5 min) — humano
Cola Private Key + Funder Address + Relayer Key num arquivo `.env`.
Clica no atalho **"BOT BIT ADICT"** no Desktop. Bot opera 24/7.

**TOTAL**: 30 minutos do zero ao primeiro trade real.

## ⚠️ Antes de começar, confere `1_PRE_REQUISITOS.md`

5 verificações de 30 segundos cada. **Se algo aí falhar, NÃO instala** — me chama no WhatsApp +55 61 99811-0979 que resolvo antes.

## 💬 Suporte

- 📱 WhatsApp direto: **+55 61 99811-0979** (resposta em até 1h em horário comercial BR/PT)
- 🟢 Grupo BIT ADICT (atualizações + dicas): https://chat.whatsapp.com/Eux7TBBova57booMCYJHmA
- 📻 Site: https://radiobitcoin.org
- ⚡ Lightning (zaps de agradecimento): `texugorecords@walletofsatoshi.com`
- 📡 Nostr: `npub1paqf0rwntldy09svmk3rgk7ppguuemxxcqpyph03pfsxwespg6jsz83k9n`

## ⚠️ Avisos importantes

- **NUNCA pedimos sua seed phrase** por WhatsApp, email ou qualquer canal. Se alguém pedir, é GOLPE.
- Recovery Kit roda **100% offline** — recomendamos desligar Wi-Fi/Ethernet durante uso pra segurança extra.
- Bots começam em **`DRY_RUN=false`** (live) com banca pequena ($10-50). Aumenta gradualmente após 7 dias observando.
- Stop-loss configurável em todos os bots — **não desative**.
- Conteúdo educacional. Não somos consultores de investimento credenciados pela CVM/CMVM. Resultados passados não garantem resultados futuros.

## 📊 Histórico real

- **Operação em produção desde Maio/2026**
- Primeiro trade ao vivo do filho do criador (10 anos): Bitcoin Up @ 45¢ → 51.5¢ (+14.44% em minutos)
- Bot DIRECIONAL v2 com mais de 11+ trades vencedores em sequência (madrugada 20/mai/2026)
- Win Rate observado: 70-80% conforme volatilidade do mercado

---

**Versão:** 2.0 (2026-05-21)
**Operação Vale Sats Global · BIT ADICT · 2026**
