# Bitadict Security Recovery Kit

**Crypto Recovery, Secured.** — utilitario **100% offline** pra recuperar acesso a wallets crypto.

Add-on oficial do ecossistema BIT ADICT.

## Aviso de seguranca

**BIT ADICT NUNCA pede sua seed phrase ou senha** — por mensagem, email, suporte, ligacao ou qualquer outro meio. Se alguem pedir, é GOLPE.

Este utilitario roda 100% offline no seu PC. Os dados que voce digita NUNCA saem da sua maquina.

## Funcoes

1. **Validar seed BIP39** — verifica checksum, detecta typo, sugere palavra correta (Levenshtein)
2. **Recovery parcial** — reconstroi seed com 1-2 palavras faltantes (marca como `?`)
3. **Bruteforce senha Monero** — testa wordlist no seu arquivo `.keys`
4. **Verificar saldo** — consulta BTC, ETH, SOL e 7 chains EVM por address publico

## Como rodar

```bash
pip install bip-utils
python3 recovery_kit.py
```

Pra Monero bruteforce: `brew install monero` (Mac) ou baixar de getmonero.org.

## Landing publica

https://kit.radiobitcoin.org

## Open source

Codigo aberto pra voce auditar. Nao envia nada pra servidor.

## Doacao opcional

Quando o kit recupera com sucesso (recovery parcial ou bruteforce Monero), aparece
um popup convidando a doar uma fracao do valor recuperado (1-5%). Configuracao em
`doacao.json` — preencha os enderecos BTC/USDC/ETH/XMR pra ativar. Sem cadastro,
sem coleta de dados, 100% opcional. Pra desativar: `"habilitado": false`.
