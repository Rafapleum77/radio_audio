# 🔧 Troubleshooting · soluções pros 15 problemas mais comuns

> **Apanhamos cada um desses no primeiro deploy real**. Aqui tem solução pronta.
> Suporte WhatsApp: **+55 61 99811-0979**

---

## 1. `2_INSTALAR.bat` fecha sozinho no meio

**Sintoma**: janela do CMD fecha sem terminar, sem mensagem clara.

**Causa**: você clicou duplo nele em vez de "Executar como administrador".

**Solução**:
- Fecha tudo
- **Botão direito** em `2_INSTALAR.bat` → **Executar como administrador**
- Aceita o UAC (popup azul) clicando "Sim"
- Agora segue até o final

---

## 2. `2_INSTALAR.bat` trava em "Configurando DNS Cloudflare"

**Sintoma**: passo [2/8] fica parado mais de 1 minuto.

**Causa**: Windows muito travado de updates pendentes.

**Solução**:
- Pressiona Ctrl+C 2x pra cancelar
- Reinicia o PC normalmente
- Aguarda atualizações do Windows completarem
- Rodar `2_INSTALAR.bat` novamente

---

## 3. Erro: `clob.polymarket.com — DNS_PROBE_FINISHED_NXDOMAIN`

**Sintoma**: Chrome não abre Polymarket, ou bot dá erro "getaddrinfo failed".

**Causa**: ISP/roteador filtrando o domínio.

**Solução em ordem**:
1. Roda no PowerShell admin:
   ```
   Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ('1.1.1.1','1.0.0.1') }
   ipconfig /flushdns
   ```
2. **Desabilita IPv6** (causa mais comum):
   ```
   Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { Disable-NetAdapterBinding -Name $_.Name -ComponentID ms_tcpip6 }
   ```
3. Testa: `nslookup clob.polymarket.com 1.1.1.1`
4. **Se ainda não resolver** → usa 4G do celular como hotspot OU instala Cloudflare WARP em https://1.1.1.1/

---

## 4. Erro Python: `ModuleNotFoundError: No module named 'requests'` (ou outra lib)

**Sintoma**: bot abre, mostra `Traceback`, depois fecha.

**Causa**: Windows pegou Python 3.14 da Microsoft Store em vez do 3.11. Lib `cffi`/`coincurve` não compilam pra 3.14.

**Solução**:
```
where python
py -3.11 --version
```

- Se `py -3.11 --version` retornar erro: precisa instalar Python 3.11 via winget:
  ```
  winget install Python.Python.3.11
  ```
- Depois fecha o PowerShell, abre de novo, e usa **sempre** `py -3.11` em vez de `python`:
  ```
  cd C:\BIT_ADICT
  py -3.11 -m pip install requests python-dotenv bip-utils web3 pandas numpy pillow ccxt py_clob_client_v2
  py -3.11 bot_direcional_v2.py
  ```

---

## 5. Bot diz: `[Web3] Saldo: $0.00 | Allowance: $0.00` mas Polymarket UI mostra dinheiro

**Sintoma**: tu vê $50 na carteira da Polymarket, mas bot insiste em $0.

**Causa**: a conta foi criada via email = **Deposit Wallet** (custodial). Saldo é interno da Polymarket, não onchain.

**Solução**:
1. Settings → **Chaves API do Relayer** → **+ Criar nova** → copia a chave UUID
2. Cola no `.env`:
   ```
   RELAYER_API_KEY=cole-aqui-a-chave-uuid
   RELAYER_API_KEY_ADDRESS=cole-aqui-o-endereco-assinante
   SIGNATURE_TYPE=POLY_1271
   ```
3. Reinicia o bot

Polymarket aceita ordens via "deposit wallet flow" com signature_type 3 (POLY_1271).

---

## 6. Bot dá erro: `"maker address not allowed, please use the deposit wallet flow"`

**Sintoma**: bot detecta sinal forte, tenta postar, Polymarket rejeita com essa mensagem.

**Causa**: bot usando `signature_type=POLY_PROXY` mas a wallet é Deposit Wallet.

**Solução**: no arquivo `.env` adicione/altere:
```
SIGNATURE_TYPE=POLY_1271
```

E também crie Relayer API Key (problema #5).

---

## 7. Polymarket não abre depósito (cartão recusado)

**Sintoma**: tu clica "Deposit → Buy with card", preenche, e dá erro/recusa.

**Causa mais comum**: cartão sem compras internacionais habilitadas, ou cartão pré-pago (Wise/Revolut), ou banco bloqueando.

**Solução**:
1. Liga pro banco e fala: "**autoriza compras internacionais no meu cartão por 24h**"
2. Tenta de novo com **valor pequeno** ($30) pra teste
3. Se persistir: usa **outro cartão** (Nubank/Inter aceitam bem) ou **deposita via USDC Polygon** de exchange (mais soberano)

---

## 8. Depósito via cartão funcionou mas saldo onchain é $0

**Sintoma**: pagamento aprovado, Polymarket mostra saldo, mas blockchain mostra $0 no endereço.

**Causa**: NORMAL pra Deposit Wallet — saldo fica em treasury interno (`0x4cd00e387...`).

**Solução**: já resolvido pelo `signature_type=POLY_1271` (problema #5). Não precisa fazer nada.

---

## 9. Tela de login do Windows pede senha que não funciona

**Sintoma**: PC reinicia, pede senha, nenhuma funciona, dá "bem-vindo" e volta.

**Causa**: cache local de senha desatualizado após mudança online da conta Microsoft.

**Solução**:
1. **Na tela de login**, conecta Wi-Fi/Ethernet ANTES de digitar senha (ícone canto inferior direito)
2. Espera 1-2 min pra Windows sincronizar com Microsoft
3. Tenta senha nova
4. Se não der: troca pra **conta local** sem senha (`netplwiz` quando entrar)

Pior caso: **leva PC numa loja de informática** (R$50, 30 min) pra reset de senha sem perder dados.

---

## 10. Bot inicia mas fica `aguardando proximo sinal UP/DOWN BTC 5min...` por horas

**Sintoma**: nenhum sinal detectado, P&L sempre $0.

**Causa**: `CONFIANCA_MIN=70` é conservador. Em mercados de baixa volatilidade, sinais com 70%+ são raros.

**Solução**: relaxe o filtro no `.env`:
```
CONFIANCA_MIN=60
```

Mais sinais = mais trades, mas qualidade um pouco menor. Equilíbrio recomendado: 60-65.

---

## 11. Erro `LICENSE file in cffi distribution`

**Sintoma**: durante `pip install`, vermelho com texto sobre `cffi` e `coincurve`.

**Causa**: Python 3.14 (Microsoft Store) tentando compilar libs sem wheel pronto.

**Solução**: mesma do problema #4 — usa Python 3.11 via winget e `py -3.11 -m pip install`.

---

## 12. Setup baixou versão antiga do .bat (cache Chrome)

**Sintoma**: baixaste `2_INSTALAR.bat`, abriu, mas erro que era de versão antiga.

**Causa**: Chrome cacheia arquivos `.bat`.

**Solução**:
- Chrome → Configurações → Privacidade → **Limpar dados de navegação** → Imagens em cache e arquivos
- OU adiciona `?v=2` no fim da URL: `radiobitcoin.org/setup.bat?v=2`
- OU baixa pelo **modo anônimo** (Ctrl+Shift+N)

---

## 13. AnyDesk conecta mas só mostra tela de bloqueio

**Sintoma**: AnyDesk entra no PC remoto mas vê tela de login do Windows, não consegue trabalhar.

**Causa**: ninguém tá logado no Windows na máquina remota.

**Solução**:
- **Fisicamente no PC remoto**: faz login no Windows uma vez
- Depois AnyDesk passa a ver o Desktop normalmente
- Pra evitar isso: ativa **auto-login** (problema #14)

---

## 14. Auto-login Windows pra bot reiniciar sozinho após boot

**Sintoma**: PC reiniciou (queda luz/update), bot não roda porque ninguém logou.

**Solução**:
- `Windows + R` → `netplwiz` → Enter
- Seleciona o usuário
- Desmarca **"Os usuários devem digitar um nome de usuário e senha..."**
- OK → digita senha atual 2x → OK
- Reinicia → PC entra direto

Combina com **Task Scheduler** pra rodar `bot_direcional_v2.py` no boot.

---

## 15. Erro "Allowance insuficiente! Aprova em polymarket.com"

**Sintoma**: bot quer abrir trade mas diz que allowance é zero.

**Causa**: aprovação USDC ainda não foi feita.

**Solução**:
1. Vai em polymarket.com no Chrome
2. Faz **1 trade manual de teste** ($1 em qualquer mercado)
3. Polymarket vai pedir "Approve USDC" → clica "Approve" (Polymarket paga o gas)
4. Não precisa nem concluir o trade — só o approve já libera
5. Volta pro bot, ele detecta na próxima iteração

**Alternativa**: ativa **Settings → Negociação → Resgata os teus ganhos automaticamente** → também faz o approve automático.

---

## 🆘 Travado em algo que não tá aqui?

WhatsApp **+55 61 99811-0979** com:
1. Print da tela com o erro
2. Conteúdo do arquivo `C:\BIT_ADICT\setup.log` (últimas 20 linhas)
3. Em qual passo do `MANUAL_v3.md` você tava

Respondo em até 1h em horário comercial BR/PT.

---

**Versão troubleshooting:** 2.0 (2026-05-21)
