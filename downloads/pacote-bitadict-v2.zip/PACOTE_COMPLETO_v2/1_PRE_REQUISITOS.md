# ✅ Pré-requisitos · 5 verificações (30s cada)

> Antes de rodar o `2_INSTALAR.bat`, confere os 5 itens abaixo.
> **Se algum falhar, ME CHAMA antes** — WhatsApp +55 61 99811-0979. Não tenta forçar.

## ✅ 1) Windows 10 ou 11 (não Windows 7/8/XP)

**Como conferir:**
- Tecla `Windows + Pause` → abre janela "Sobre"
- **Edição do Windows** deve mostrar: `Windows 10` ou `Windows 11`
- Tipo de sistema: **64 bits**

**Se for outro:** o bot não funciona em Windows 7/8. Solução: atualizar pra Windows 10/11 (gratuito via update Microsoft) **antes** de instalar o pacote.

## ✅ 2) Conta de usuário **sem complicação de senha**

**Como conferir:**
- O usuário onde tu instala precisa ser **administrador**
- Senha do Windows deve estar **anotada** (não esquecida)
- **De preferência: conta LOCAL** (não conta Microsoft), porque conta Microsoft pede internet ao logar

**Como saber se é conta Microsoft ou Local:**
- Configurações → Contas → **Suas informações**
- Se aparecer email (ex: xxx@hotmail.com) = **conta Microsoft**
- Se aparecer só nome (ex: "Lenovo") = **conta Local**

**Se for conta Microsoft com senha esquecida ou complicada:** considera criar conta local nova **antes** de instalar:
- Configurações → Contas → Família e outros usuários → **Adicionar conta**
- Escolhe "Não tenho informações de login dessa pessoa"
- "Adicionar usuário sem conta Microsoft"
- Define nome simples (ex: `bot`) e senha curta numérica (ex: `0000`) ou deixa em branco
- Tornar Administrador

## ✅ 3) Internet sem filtros de conteúdo

**Como conferir (1 teste de 10 segundos):**
- Abre o Chrome
- Cola na barra de endereço:
  ```
  clob.polymarket.com
  ```
- Aperta Enter

**Resultado:**
- ✅ Abre página com texto JSON tipo `{"status": "ok"}` → **TUDO CERTO**
- ❌ "Não foi possível acessar este site" / "DNS_PROBE_FINISHED_NXDOMAIN" → **Roteador/ISP bloqueia**

**Se bloquear**, o `2_INSTALAR.bat` configura DNS Cloudflare automaticamente, mas se mesmo assim falhar, é o **ISP filtrando por IP**. Soluções (em ordem):

1. **Trocar de rede Wi-Fi** (4G do celular como hotspot resolve 100%)
2. **NordVPN** (recomendamos pra clientes — €3/mês, conexão sem filtros) — vamos te indicar afiliado se quiser
3. **Cloudflare WARP** (grátis, sem cadastro): https://1.1.1.1/

## ✅ 4) Cartão de crédito internacional OU exchange BR/PT com USDC

Pra depositar o capital inicial na Polymarket (sugerimos começar com **$30-100**).

**Opção A — Cartão de crédito** (mais simples):
- Cartão **Visa ou Mastercard** com **compras internacionais habilitadas**
- Saldo disponível: pelo menos $30 USD + ~10% (taxas+spread)
- Bancos BR que costumam aceitar: Nubank, Inter, BTG, C6
- Bancos PT: Millennium, BCP, Santander
- ⚠️ Cartão pré-pago (Wise, Revolut) **às vezes é rejeitado** pela Polymarket — testa antes

**Opção B — USDC de exchange** (mais soberano):
- Tu já tem USDC em alguma exchange?
- Binance, Mercado Bitcoin, Bitypreço, OKX, etc — funciona
- Vai enviar USDC via rede **Polygon** (taxa ~$0.10) pro endereço de depósito Polymarket
- Mais barato e rápido que cartão, mas exige saber mexer com crypto

## ✅ 5) Espaço em disco e RAM

**Como conferir:**
- Espaço livre em `C:\`: **mínimo 2GB**
- RAM total: **mínimo 4GB** (8GB recomendado)

**Como ver:**
- Tecla `Windows + E` → clica em "Este Computador" → vê quanto livre em C:
- Tecla `Windows + Pause` → linha "Memória instalada (RAM)"

**Se faltar espaço/RAM:** computador muito antigo pode rodar o bot, mas Chrome+bot juntos vão ficar lentos. Considera deixar bot rodando e fechar outras coisas.

## ✅ 6) Configurações de Energia (CRÍTICO pro bot rodar 24/7)

> **Por padrão o Windows desliga disco/suspende PC pra "economizar".** Pra bot operar 24/7 sem perder trades, tu precisa ajustar 5 coisas.

### Onde:
**Tecla Windows + R** → digita `control` → Enter → **Opções de Energia**

### As 5 configs:

| # | Config | Onde achar | Valor correto |
|---|--------|-----------|---------------|
| 1 | **Inicialização Rápida** | Lado esquerdo → "Escolher função dos botões de energia" → "Alterar configurações não disponíveis" → embaixo "Configurações de desligamento" | ❌ **DESMARCADO** |
| 2 | **Plano de energia** | Página principal | ⚡ **Alto Desempenho** (não Equilibrado) |
| 3 | **Colocar PC em suspensão** | "Alterar plano de energia" do plano ativo | ⛔ **Nunca** |
| 4 | **Desligar vídeo** | mesmo lugar | ⏱️ 15 min OK (só desliga monitor, PC fica acordado) |
| 5 | **Desligar disco rígido** | "Alterar configurações avançadas" → "Disco rígido" | ⛔ **Nunca** (Configuração: 0 minutos = Nunca) |

### Por quê isso importa:

| Sem ajuste | Com ajuste |
|------------|------------|
| ❌ Bot pode bugar ao "ligar" PC depois de fast startup | ✅ Boot completo sempre |
| ❌ PC suspende sozinho → bot perde trades | ✅ PC 24/7 acordado |
| ❌ SSD desliga e bot trava ao gravar log | ✅ Operação contínua |
| ❌ Windows Update aplica pela metade | ✅ Atualizações limpas |
| ❌ AnyDesk não inicia bem após shutdown | ✅ Acesso remoto sempre disponível |

**Dica**: faz isso UMA VEZ na vida do PC. Depois esquece.

---

## ✅ Tudo certo? Vai pro passo seguinte

Se as 5 verificações passaram, **clica com BOTÃO DIREITO** em `2_INSTALAR.bat` → **Executar como administrador**.

Se travar em algum passo, abre `3_MANUAL_v3.md` ou `4_TROUBLESHOOTING.md`.

---

**Versão pré-requisitos:** 2.0 (2026-05-21)
**Suporte:** WhatsApp +55 61 99811-0979
